# Claude Account Switcher

A local dashboard that switches your Claude Code login between multiple accounts with **one click** — sign in to each account once, never re-authenticate again. See every account's official usage limits live, and get a switch suggestion the moment your active account runs low.

## Set up on any PC (one time)

1. Copy this folder anywhere on the PC.
2. Double-click **`setup.cmd`** — it installs Node.js if missing, puts a shortcut on the Desktop, and opens the app.
3. That's it. Day-to-day, open it from the Desktop shortcut (or `start.cmd`).

Moving accounts from an old PC? On the old one: **Settings → Export accounts**. On the new one: **Settings → Import accounts**. No sign-ins needed.

## What it does

| Feature | Detail |
|---|---|
| One-click switch | Swaps the saved login into place. Running Claude windows finish on the old account; everything new uses the new one. |
| Live usage limits | Official 5-hour and weekly usage per account — the same numbers as `/usage`, refreshed every few minutes, costs nothing. |
| Switch suggestion | Active account crosses 90% → a red box offers the account with the most room. |
| Guided add-account | "Add account" opens the sign-in terminal for you and detects the new login automatically. |
| Auto-renew | Saved logins are refreshed in the background so they stay valid. |
| Backups | Login files are backed up before every switch (last 10, one-click restore, always reversible). |
| Activity | History of every switch, save, restore, and import. |
| Export / Import | Move all accounts to another PC in one file. |
| Start with Windows | Optional — runs at sign-in and restarts itself if it ever stops. |
| Dark mode | Toggle in the top bar. |

## How switching works

Claude Code keeps your login in two files:

- `%USERPROFILE%\.claude\.credentials.json` — OAuth access + refresh tokens
- `%USERPROFILE%\.claude.json` — the `oauthAccount` section (email, org, plan)

Saving a profile snapshots both; switching writes the snapshot back (only the `oauthAccount` key of `.claude.json` is touched, atomically, with a backup first). No browser login is needed because the refresh token stays valid ~30 days and is renewed automatically. Before every switch, live tokens are **synced back** into the matching profile so snapshots never go stale.

## Code structure

```
server.js          entry point: wiring, error handling, port logic
lib/
  files.js         paths, atomic writes, live login reader
  profiles.js      profile store, export/import
  switcher.js      sync-back, backups, switch, restore, state
  usage.js         usage API client, token refresh, caching
  autostart.js     Start-with-Windows launcher
  events.js        activity history
  log.js           size-capped app log
  server.js        HTTP API + static files + local-only security
public/
  index.html       markup
  app.css          styles (light + dark)
  app.js           front-end logic
server.test.js     39 automated tests (node --test server.test.js)
setup.cmd          one-time setup for any PC
start.cmd          daily launcher (app window)
```

Zero npm dependencies — Node.js built-ins only.

## Security

- The server binds `127.0.0.1` only, and rejects DNS-rebinding / cross-origin requests (Host, Origin, and Content-Type checks).
- Tokens never appear in API responses, the UI, or logs.
- `profiles.json`, `backups/`, and export files contain **real logins** — they stay on your machine and are git-ignored. Never commit or share them.

## Troubleshooting

- **Dashboard says "Can't reach the app"** — run `start.cmd` again.
- **Port 4789 is taken by another program** — run with a different port: `set PORT=4790 && node server.js`.
- **Something looks broken after a switch** — Backups → Restore the newest entry.
- **Errors** are written to `app.log` next to the app.
