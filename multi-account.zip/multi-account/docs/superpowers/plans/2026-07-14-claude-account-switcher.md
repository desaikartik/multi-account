# Claude Code Account Switcher Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Local web dashboard that saves multiple Claude Code account logins as named profiles and switches the live account with one click — no repeated OAuth.

**Architecture:** Single `server.js` (Node built-ins only) holds all logic and exports every function for tests; `public/index.html` is the whole UI; `profiles.json` + `backups/` are the store. Switching = atomically rewriting `~/.claude/.credentials.json` and the `oauthAccount` key of `~/.claude.json` from a saved snapshot, with sync-back of the live account's refreshed tokens before every switch.

**Tech Stack:** Node v22 (`http`, `fs`, `path`, `os`, `crypto`, built-in `node:test`), vanilla HTML/CSS/JS. Zero npm dependencies.

## Global Constraints

- Zero npm dependencies; Node v22 built-ins only. No package.json required.
- All writes to Claude's files are atomic: temp file in same directory, then rename.
- Server binds `127.0.0.1` only, default port 4789 (env `PORT` overrides).
- Token strings NEVER appear in API responses, UI, or logs — only expiry metadata.
- `getPaths(env)` must honor `SWITCHER_HOME`, `SWITCHER_DATA_DIR` (test isolation) and `CLAUDE_CONFIG_DIR` (real Claude override).
- Keep max 10 backups; prune oldest.
- **Deviation from skill template:** this directory is not a git repository and the user has not asked for git — commit steps are replaced by verification steps.
- Spec: `docs/superpowers/specs/2026-07-14-claude-account-switcher-design.md`.

---

### Task 1: File layer — paths, JSON I/O, live-state reader

**Files:**
- Create: `d:\kd\multi-account\server.js`
- Test: `d:\kd\multi-account\server.test.js`
- Delete: `d:\kd\multi-account\test.js` (empty stray file)

**Interfaces:**
- Produces: `getPaths(env?) -> {credentials, claudeJson, profiles, backups}`; `readJson(file) -> object|null`; `atomicWrite(file, content:string)`; `readLive(paths) -> {credentials: object|null, account: object|null}`; `httpError(status, message) -> Error{status}`.

- [ ] **Step 1: Write failing tests**

`server.test.js`:

```js
'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const app = require('./server.js');

// ---- helpers -------------------------------------------------------------
function makeTmpEnv() {
  const home = fs.mkdtempSync(path.join(os.tmpdir(), 'switcher-test-'));
  const dataDir = path.join(home, 'switcher-data');
  fs.mkdirSync(dataDir);
  fs.mkdirSync(path.join(home, '.claude'));
  return app.getPaths({ SWITCHER_HOME: home, SWITCHER_DATA_DIR: dataDir });
}

// Writes fake live login files for account "letter" (A, B, ...)
function writeFakeLogin(paths, letter, opts = {}) {
  const home = path.dirname(paths.claudeJson);
  fs.writeFileSync(paths.credentials, JSON.stringify({
    claudeAiOauth: {
      accessToken: 'access-' + letter + (opts.tag || ''),
      refreshToken: 'refresh-' + letter + (opts.tag || ''),
      expiresAt: Date.now() + 3600e3,
      refreshTokenExpiresAt: opts.refreshTokenExpiresAt ?? Date.now() + 30 * 86400e3,
      scopes: ['user:inference'],
      subscriptionType: 'team',
      rateLimitTier: 'default_tier',
    },
  }));
  fs.writeFileSync(paths.claudeJson, JSON.stringify({
    unrelatedKey: 'preserve-me',
    oauthAccount: {
      accountUuid: 'uuid-' + letter,
      emailAddress: letter.toLowerCase() + '@test.com',
      organizationName: 'Org ' + letter,
      displayName: 'User ' + letter,
    },
  }));
  return home;
}

// ---- Task 1 tests ----------------------------------------------------------
test('getPaths honors SWITCHER_HOME and SWITCHER_DATA_DIR', () => {
  const p = app.getPaths({ SWITCHER_HOME: '/tmp/h', SWITCHER_DATA_DIR: '/tmp/d' });
  assert.ok(p.credentials.includes(path.join('h', '.claude', '.credentials.json')));
  assert.ok(p.claudeJson.includes(path.join('h', '.claude.json')));
  assert.ok(p.profiles.includes(path.join('d', 'profiles.json')));
  assert.ok(p.backups.includes(path.join('d', 'backups')));
});

test('getPaths honors CLAUDE_CONFIG_DIR for credentials only', () => {
  const p = app.getPaths({ SWITCHER_HOME: '/tmp/h', SWITCHER_DATA_DIR: '/tmp/d', CLAUDE_CONFIG_DIR: '/tmp/cfg' });
  assert.ok(p.credentials.includes(path.join('cfg', '.credentials.json')));
  assert.ok(p.claudeJson.includes(path.join('h', '.claude.json')));
});

test('readLive returns credentials and account from live files', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  const live = app.readLive(paths);
  assert.equal(live.credentials.accessToken, 'access-A');
  assert.equal(live.account.emailAddress, 'a@test.com');
});

test('readLive returns nulls when files are missing', () => {
  const paths = makeTmpEnv();
  const live = app.readLive(paths);
  assert.equal(live.credentials, null);
  assert.equal(live.account, null);
});

test('atomicWrite replaces existing file content', () => {
  const paths = makeTmpEnv();
  const f = path.join(path.dirname(paths.profiles), 'x.json');
  app.atomicWrite(f, '{"a":1}');
  app.atomicWrite(f, '{"a":2}');
  assert.deepEqual(JSON.parse(fs.readFileSync(f, 'utf8')), { a: 2 });
  assert.equal(fs.readdirSync(path.dirname(f)).filter(n => n.includes('.tmp-')).length, 0);
});
```

- [ ] **Step 2: Run tests, verify they fail**

Run: `cd d:/kd/multi-account && node --test server.test.js`
Expected: FAIL — `Cannot find module './server.js'` (or missing exports).

- [ ] **Step 3: Implement**

`server.js`:

```js
#!/usr/bin/env node
'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const crypto = require('crypto');

// ---------------------------------------------------------------- file layer
function getPaths(env = process.env) {
  const home = env.SWITCHER_HOME || os.homedir();
  const configDir = env.CLAUDE_CONFIG_DIR || path.join(home, '.claude');
  const dataDir = env.SWITCHER_DATA_DIR || __dirname;
  return {
    credentials: path.join(configDir, '.credentials.json'),
    claudeJson: path.join(home, '.claude.json'),
    profiles: path.join(dataDir, 'profiles.json'),
    backups: path.join(dataDir, 'backups'),
  };
}

function readJson(file) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return null; }
}

function atomicWrite(file, content) {
  const tmp = file + '.tmp-' + crypto.randomBytes(4).toString('hex');
  fs.writeFileSync(tmp, content);
  fs.renameSync(tmp, file);
}

function readLive(paths) {
  const credsFile = readJson(paths.credentials);
  const claudeJson = readJson(paths.claudeJson);
  return {
    credentials: (credsFile && credsFile.claudeAiOauth) || null,
    account: (claudeJson && claudeJson.oauthAccount) || null,
  };
}

function httpError(status, message) {
  const err = new Error(message);
  err.status = status;
  return err;
}

module.exports = { getPaths, readJson, atomicWrite, readLive, httpError };
```

- [ ] **Step 4: Run tests, verify pass**

Run: `cd d:/kd/multi-account && node --test server.test.js`
Expected: all Task 1 tests PASS. Also delete stray empty `test.js`.

---

### Task 2: Profile store — save current account, rename, delete

**Files:**
- Modify: `d:\kd\multi-account\server.js` (append functions, extend exports)
- Test: `d:\kd\multi-account\server.test.js` (append tests)

**Interfaces:**
- Consumes: Task 1 (`getPaths`, `readJson`, `atomicWrite`, `readLive`, `httpError`).
- Produces: `loadProfiles(paths) -> {activeProfile: string|null, profiles: {[name]: {credentials, account, savedAt, lastUsedAt}}}`; `saveProfiles(paths, store)`; `saveCurrentAsProfile(paths, name) -> {name, updated: boolean}`; `sanitizeName(raw) -> string`; `renameProfile(paths, oldName, newName)`; `deleteProfile(paths, name)`.

- [ ] **Step 1: Write failing tests** (append to `server.test.js`)

```js
// ---- Task 2 tests ----------------------------------------------------------
test('saveCurrentAsProfile snapshots the live account', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  const res = app.saveCurrentAsProfile(paths, 'work');
  assert.deepEqual(res, { name: 'work', updated: false });
  const store = app.loadProfiles(paths);
  assert.equal(store.profiles.work.account.emailAddress, 'a@test.com');
  assert.equal(store.profiles.work.credentials.refreshToken, 'refresh-A');
  assert.equal(store.activeProfile, 'work');
  assert.ok(store.profiles.work.savedAt);
});

test('saveCurrentAsProfile throws 409 when not logged in', () => {
  const paths = makeTmpEnv();
  assert.throws(() => app.saveCurrentAsProfile(paths, 'work'), /login/i);
});

test('saving the same account again updates the existing profile, no duplicate', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  app.saveCurrentAsProfile(paths, 'work');
  writeFakeLogin(paths, 'A', { tag: '-v2' }); // same uuid, refreshed tokens
  const res = app.saveCurrentAsProfile(paths, 'differentName');
  assert.deepEqual(res, { name: 'work', updated: true });
  const store = app.loadProfiles(paths);
  assert.equal(Object.keys(store.profiles).length, 1);
  assert.equal(store.profiles.work.credentials.accessToken, 'access-A-v2');
});

test('name collision with a different account throws 409', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  app.saveCurrentAsProfile(paths, 'work');
  writeFakeLogin(paths, 'B');
  assert.throws(() => app.saveCurrentAsProfile(paths, 'work'), /already exists/i);
});

test('sanitizeName rejects empty and >40 chars', () => {
  assert.throws(() => app.sanitizeName(''), /1-40/);
  assert.throws(() => app.sanitizeName('x'.repeat(41)), /1-40/);
  assert.equal(app.sanitizeName('  work  '), 'work');
});

test('renameProfile moves entry and updates activeProfile', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  app.saveCurrentAsProfile(paths, 'work');
  app.renameProfile(paths, 'work', 'office');
  const store = app.loadProfiles(paths);
  assert.ok(store.profiles.office);
  assert.equal(store.profiles.work, undefined);
  assert.equal(store.activeProfile, 'office');
  assert.throws(() => app.renameProfile(paths, 'nope', 'x'), /not found/i);
});

test('deleteProfile removes entry and clears activeProfile if it pointed there', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  app.saveCurrentAsProfile(paths, 'work');
  app.deleteProfile(paths, 'work');
  const store = app.loadProfiles(paths);
  assert.equal(Object.keys(store.profiles).length, 0);
  assert.equal(store.activeProfile, null);
});
```

- [ ] **Step 2: Run tests, verify new ones fail**

Run: `node --test server.test.js` — Task 2 tests FAIL (`app.saveCurrentAsProfile is not a function`).

- [ ] **Step 3: Implement** (append to `server.js`, before `module.exports`; extend exports)

```js
// ------------------------------------------------------------- profile store
function loadProfiles(paths) {
  return readJson(paths.profiles) || { activeProfile: null, profiles: {} };
}

function saveProfiles(paths, store) {
  atomicWrite(paths.profiles, JSON.stringify(store, null, 2));
}

function sanitizeName(raw) {
  const name = String(raw || '').trim();
  if (!name || name.length > 40) throw httpError(400, 'Name must be 1-40 characters.');
  return name;
}

function findProfileByUuid(store, accountUuid) {
  return Object.keys(store.profiles)
    .find(n => store.profiles[n].account.accountUuid === accountUuid) || null;
}

function saveCurrentAsProfile(paths, name) {
  const live = readLive(paths);
  if (!live.credentials || !live.account) {
    throw httpError(409, 'No live login found — run `claude /login` in a terminal first.');
  }
  const store = loadProfiles(paths);
  const existingName = findProfileByUuid(store, live.account.accountUuid);
  const finalName = existingName || name;
  if (!existingName && store.profiles[finalName]) {
    throw httpError(409, `Profile "${finalName}" already exists for a different account.`);
  }
  const prev = store.profiles[finalName];
  store.profiles[finalName] = {
    credentials: live.credentials,
    account: live.account,
    savedAt: new Date().toISOString(),
    lastUsedAt: (prev && prev.lastUsedAt) || null,
  };
  store.activeProfile = finalName;
  saveProfiles(paths, store);
  return { name: finalName, updated: Boolean(existingName) };
}

function renameProfile(paths, oldName, newName) {
  const store = loadProfiles(paths);
  if (!store.profiles[oldName]) throw httpError(404, `Profile "${oldName}" not found.`);
  if (store.profiles[newName]) throw httpError(409, `Profile "${newName}" already exists.`);
  store.profiles[newName] = store.profiles[oldName];
  delete store.profiles[oldName];
  if (store.activeProfile === oldName) store.activeProfile = newName;
  saveProfiles(paths, store);
}

function deleteProfile(paths, name) {
  const store = loadProfiles(paths);
  if (!store.profiles[name]) throw httpError(404, `Profile "${name}" not found.`);
  delete store.profiles[name];
  if (store.activeProfile === name) store.activeProfile = null;
  saveProfiles(paths, store);
}
```

Exports become:
```js
module.exports = {
  getPaths, readJson, atomicWrite, readLive, httpError,
  loadProfiles, saveProfiles, sanitizeName, saveCurrentAsProfile,
  renameProfile, deleteProfile,
};
```

- [ ] **Step 4: Run tests, verify pass** — `node --test server.test.js`, all PASS.

---

### Task 3: Switch engine — sync-back, backups, switch, restore, state

**Files:**
- Modify: `d:\kd\multi-account\server.js`
- Test: `d:\kd\multi-account\server.test.js`

**Interfaces:**
- Consumes: Tasks 1–2.
- Produces: `syncBack(paths, store) -> string|null` (profile name updated); `makeBackup(paths) -> string` (backup id); `listBackups(paths) -> string[]` (newest first); `switchToProfile(paths, name) -> {switched: string}`; `restoreBackup(paths, id) -> {restored: string}`; `getState(paths) -> {live, activeProfile, profiles[]}` — `profiles[]` items: `{name, email, organization, displayName, tier, rateLimitTier, refreshTokenExpiresAt, savedAt, lastUsedAt, isLive}`.

- [ ] **Step 1: Write failing tests** (append)

```js
// ---- Task 3 tests ----------------------------------------------------------
test('switchToProfile writes target tokens and patches only oauthAccount', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  app.saveCurrentAsProfile(paths, 'acct-a');
  writeFakeLogin(paths, 'B');
  app.saveCurrentAsProfile(paths, 'acct-b');
  const res = app.switchToProfile(paths, 'acct-a');
  assert.deepEqual(res, { switched: 'acct-a' });
  const creds = JSON.parse(fs.readFileSync(paths.credentials, 'utf8'));
  assert.equal(creds.claudeAiOauth.accessToken, 'access-A');
  const cj = JSON.parse(fs.readFileSync(paths.claudeJson, 'utf8'));
  assert.equal(cj.oauthAccount.accountUuid, 'uuid-A');
  assert.equal(cj.unrelatedKey, 'preserve-me'); // rest of .claude.json untouched
  assert.equal(app.loadProfiles(paths).activeProfile, 'acct-a');
});

test('switch syncs refreshed live tokens back into the matching profile first', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  app.saveCurrentAsProfile(paths, 'acct-a');
  writeFakeLogin(paths, 'B');
  app.saveCurrentAsProfile(paths, 'acct-b');
  // Simulate Claude Code refreshing B's tokens on disk after the snapshot:
  writeFakeLogin(paths, 'B', { tag: '-refreshed' });
  app.switchToProfile(paths, 'acct-a');
  const store = app.loadProfiles(paths);
  assert.equal(store.profiles['acct-b'].credentials.refreshToken, 'refresh-B-refreshed');
});

test('switch to a profile with expired refresh token throws 409', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A', { refreshTokenExpiresAt: Date.now() - 1000 });
  app.saveCurrentAsProfile(paths, 'stale');
  writeFakeLogin(paths, 'B');
  assert.throws(() => app.switchToProfile(paths, 'stale'), /expired/i);
});

test('switch aborts without writing when .claude.json is corrupt', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  app.saveCurrentAsProfile(paths, 'acct-a');
  fs.writeFileSync(paths.claudeJson, '{ this is not json');
  assert.throws(() => app.switchToProfile(paths, 'acct-a'));
  const rawCreds = fs.readFileSync(paths.credentials, 'utf8');
  assert.ok(rawCreds.includes('access-A')); // credentials untouched by aborted switch
});

test('each switch creates a backup, pruned to 10', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  app.saveCurrentAsProfile(paths, 'acct-a');
  for (let i = 0; i < 12; i++) app.makeBackup(paths);
  assert.equal(app.listBackups(paths).length, 10);
});

test('restoreBackup puts old files back, even when backups are at capacity', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  const backupId = app.makeBackup(paths);
  writeFakeLogin(paths, 'B');
  for (let i = 0; i < 9; i++) app.makeBackup(paths); // fill to capacity
  const res = app.restoreBackup(paths, backupId);
  assert.equal(res.restored, backupId);
  const creds = JSON.parse(fs.readFileSync(paths.credentials, 'utf8'));
  assert.equal(creds.claudeAiOauth.accessToken, 'access-A');
});

test('restoreBackup rejects path-traversal ids', () => {
  const paths = makeTmpEnv();
  assert.throws(() => app.restoreBackup(paths, '..\\..\\evil'), /bad backup id/i);
});

test('getState reports live account, matched profile, and never leaks tokens', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  app.saveCurrentAsProfile(paths, 'acct-a');
  const state = app.getState(paths);
  assert.equal(state.live.loggedIn, true);
  assert.equal(state.live.email, 'a@test.com');
  assert.equal(state.live.matchedProfile, 'acct-a');
  assert.equal(state.profiles[0].isLive, true);
  assert.ok(!JSON.stringify(state).includes('access-A'));
  assert.ok(!JSON.stringify(state).includes('refresh-A'));
});

test('getState flags drift when live account matches no profile', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  app.saveCurrentAsProfile(paths, 'acct-a');
  writeFakeLogin(paths, 'B'); // logged into unknown account outside the tool
  const state = app.getState(paths);
  assert.equal(state.live.matchedProfile, null);
  assert.equal(state.live.email, 'b@test.com');
});
```

- [ ] **Step 2: Run, verify new tests fail** — `node --test server.test.js`.

- [ ] **Step 3: Implement** (append; extend exports)

```js
// ------------------------------------------------------------- switch engine
function syncBack(paths, store) {
  const live = readLive(paths);
  if (!live.credentials || !live.account) return null;
  const name = findProfileByUuid(store, live.account.accountUuid);
  if (!name) return null;
  store.profiles[name].credentials = live.credentials;
  store.profiles[name].account = live.account;
  return name;
}

function listBackups(paths) {
  if (!fs.existsSync(paths.backups)) return [];
  return fs.readdirSync(paths.backups).sort().reverse();
}

function makeBackup(paths) {
  fs.mkdirSync(paths.backups, { recursive: true });
  const id = new Date().toISOString().replace(/[:.]/g, '-') + '-' + crypto.randomBytes(2).toString('hex');
  const dir = path.join(paths.backups, id);
  fs.mkdirSync(dir);
  for (const [copyName, source] of [['credentials.json', paths.credentials], ['claude.json', paths.claudeJson]]) {
    if (fs.existsSync(source)) fs.copyFileSync(source, path.join(dir, copyName));
  }
  for (const old of listBackups(paths).slice(10)) {
    fs.rmSync(path.join(paths.backups, old), { recursive: true, force: true });
  }
  return id;
}

function switchToProfile(paths, name) {
  const store = loadProfiles(paths);
  const profile = store.profiles[name];
  if (!profile) throw httpError(404, `Profile "${name}" not found.`);
  const rtExpiry = profile.credentials.refreshTokenExpiresAt;
  if (rtExpiry && rtExpiry < Date.now()) {
    throw httpError(409, `The saved login for "${name}" has expired. Run \`claude /login\` with that account once, then save it again.`);
  }
  // Parse .claude.json BEFORE any write — a corrupt file aborts the whole switch.
  let claudeJson = {};
  if (fs.existsSync(paths.claudeJson)) {
    claudeJson = JSON.parse(fs.readFileSync(paths.claudeJson, 'utf8'));
  }
  syncBack(paths, store);
  makeBackup(paths);
  const credsFile = readJson(paths.credentials) || {};
  credsFile.claudeAiOauth = profile.credentials;
  atomicWrite(paths.credentials, JSON.stringify(credsFile, null, 2));
  claudeJson.oauthAccount = profile.account;
  atomicWrite(paths.claudeJson, JSON.stringify(claudeJson, null, 2));
  profile.lastUsedAt = new Date().toISOString();
  store.activeProfile = name;
  saveProfiles(paths, store);
  return { switched: name };
}

function restoreBackup(paths, id) {
  if (!/^[A-Za-z0-9-]+$/.test(String(id))) throw httpError(400, 'Bad backup id.');
  const dir = path.join(paths.backups, id);
  if (!fs.existsSync(dir)) throw httpError(404, `Backup "${id}" not found.`);
  // Read backup contents into memory BEFORE making the safety backup —
  // pruning during makeBackup may delete the very directory being restored.
  const pending = [];
  for (const [copyName, target] of [['credentials.json', paths.credentials], ['claude.json', paths.claudeJson]]) {
    const src = path.join(dir, copyName);
    if (fs.existsSync(src)) pending.push([target, fs.readFileSync(src)]);
  }
  makeBackup(paths);
  for (const [target, buf] of pending) atomicWrite(target, buf.toString('utf8'));
  return { restored: id };
}

function getState(paths) {
  const live = readLive(paths);
  const store = loadProfiles(paths);
  const liveUuid = (live.account && live.account.accountUuid) || null;
  const matchedProfile = liveUuid ? findProfileByUuid(store, liveUuid) : null;
  return {
    live: {
      loggedIn: Boolean(live.credentials && live.account),
      email: live.account ? live.account.emailAddress : null,
      organization: live.account ? live.account.organizationName : null,
      accountUuid: liveUuid,
      expiresAt: live.credentials ? live.credentials.expiresAt : null,
      refreshTokenExpiresAt: live.credentials ? live.credentials.refreshTokenExpiresAt : null,
      matchedProfile,
    },
    activeProfile: store.activeProfile,
    profiles: Object.entries(store.profiles).map(([name, p]) => ({
      name,
      email: p.account.emailAddress,
      organization: p.account.organizationName,
      displayName: p.account.displayName,
      tier: p.credentials.subscriptionType || p.account.seatTier || null,
      rateLimitTier: p.credentials.rateLimitTier || null,
      refreshTokenExpiresAt: p.credentials.refreshTokenExpiresAt || null,
      savedAt: p.savedAt,
      lastUsedAt: p.lastUsedAt,
      isLive: name === matchedProfile,
    })),
  };
}
```

Add to exports: `syncBack, makeBackup, listBackups, switchToProfile, restoreBackup, getState`.

- [ ] **Step 4: Run tests, verify pass** — `node --test server.test.js`, all PASS.

---

### Task 4: HTTP server + JSON API

**Files:**
- Modify: `d:\kd\multi-account\server.js`
- Test: `d:\kd\multi-account\server.test.js`

**Interfaces:**
- Consumes: Tasks 1–3.
- Produces: `createServer(paths) -> http.Server`. Routes: `GET /` (serves `public/index.html`), `GET /api/state`, `POST /api/profiles {name}`, `POST /api/switch {name}`, `PATCH /api/profiles/:name {newName}`, `DELETE /api/profiles/:name`, `GET /api/backups`, `POST /api/restore {id}`. Errors: `{error: string}` with the thrown status. CLI entry: `node server.js` listens on `127.0.0.1:4789`.

- [ ] **Step 1: Write failing tests** (append)

```js
// ---- Task 4 tests ----------------------------------------------------------
async function withServer(paths, fn) {
  const server = app.createServer(paths);
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  try { await fn(base); } finally { server.close(); }
}

test('API: full save/switch/delete round trip', async () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  await withServer(paths, async base => {
    let res = await fetch(base + '/api/profiles', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: 'acct-a' }),
    });
    assert.equal(res.status, 200);

    writeFakeLogin(paths, 'B');
    await fetch(base + '/api/profiles', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: 'acct-b' }),
    });

    res = await fetch(base + '/api/switch', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: 'acct-a' }),
    });
    assert.deepEqual(await res.json(), { switched: 'acct-a' });

    res = await fetch(base + '/api/state');
    const state = await res.json();
    assert.equal(state.live.email, 'a@test.com');
    assert.equal(state.profiles.length, 2);

    res = await fetch(base + '/api/profiles/acct-b', { method: 'DELETE' });
    assert.equal(res.status, 200);
    res = await fetch(base + '/api/state');
    assert.equal((await res.json()).profiles.length, 1);
  });
});

test('API: errors carry status and message, unknown route is 404', async () => {
  const paths = makeTmpEnv();
  await withServer(paths, async base => {
    let res = await fetch(base + '/api/switch', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: 'ghost' }),
    });
    assert.equal(res.status, 404);
    assert.match((await res.json()).error, /not found/i);

    res = await fetch(base + '/api/nope');
    assert.equal(res.status, 404);
  });
});

test('API: rename via PATCH', async () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  await withServer(paths, async base => {
    await fetch(base + '/api/profiles', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: 'old' }),
    });
    const res = await fetch(base + '/api/profiles/old', {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ newName: 'new' }),
    });
    assert.equal(res.status, 200);
    const state = await (await fetch(base + '/api/state')).json();
    assert.equal(state.profiles[0].name, 'new');
  });
});
```

- [ ] **Step 2: Run, verify new tests fail.**

- [ ] **Step 3: Implement** (append; extend exports with `createServer`)

```js
// -------------------------------------------------------------------- server
function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', chunk => {
      data += chunk;
      if (data.length > 1e6) req.destroy();
    });
    req.on('end', () => {
      try { resolve(data ? JSON.parse(data) : {}); } catch { resolve({}); }
    });
    req.on('error', reject);
  });
}

function createServer(paths) {
  return http.createServer(async (req, res) => {
    const send = (status, obj) => {
      res.writeHead(status, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(obj));
    };
    try {
      const url = new URL(req.url, 'http://localhost');
      if (req.method === 'GET' && url.pathname === '/') {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(fs.readFileSync(path.join(__dirname, 'public', 'index.html')));
        return;
      }
      if (req.method === 'GET' && url.pathname === '/api/state') return send(200, getState(paths));
      if (req.method === 'GET' && url.pathname === '/api/backups') return send(200, listBackups(paths));

      const body = await readBody(req);
      if (req.method === 'POST' && url.pathname === '/api/profiles') {
        return send(200, saveCurrentAsProfile(paths, sanitizeName(body.name)));
      }
      if (req.method === 'POST' && url.pathname === '/api/switch') {
        return send(200, switchToProfile(paths, String(body.name || '')));
      }
      if (req.method === 'POST' && url.pathname === '/api/restore') {
        return send(200, restoreBackup(paths, String(body.id || '')));
      }
      const match = url.pathname.match(/^\/api\/profiles\/([^/]+)$/);
      if (match && req.method === 'PATCH') {
        renameProfile(paths, decodeURIComponent(match[1]), sanitizeName(body.newName));
        return send(200, { ok: true });
      }
      if (match && req.method === 'DELETE') {
        deleteProfile(paths, decodeURIComponent(match[1]));
        return send(200, { ok: true });
      }
      send(404, { error: 'Not found' });
    } catch (err) {
      send(err.status || 500, { error: err.message });
    }
  });
}

if (require.main === module) {
  const paths = getPaths();
  const port = Number(process.env.PORT) || 4789;
  createServer(paths).listen(port, '127.0.0.1', () => {
    console.log(`Claude Account Switcher running at http://localhost:${port}`);
  });
}
```

- [ ] **Step 4: Run full suite, verify all pass** — `node --test server.test.js`.

---

### Task 5: UI — `public/index.html`

**Files:**
- Create: `d:\kd\multi-account\public\index.html`

**Interfaces:**
- Consumes: the Task 4 API exactly as specified (state shape from Task 3 `getState`).
- Produces: the complete single-file UI. Design direction (from frontend-design pass): terminal instrument panel — warm near-black `#171310`, surface `#211B16`, border `#3A2E24`, text `#EDE4D8`, muted `#9A8C7D`, accent Claude-coral `#E8804F`, ok `#8FBF6F`, warn `#E3B341`, danger `#E5534B`. Monospace display (Cascadia Mono/Consolas), system sans body. Signature: blinking block cursor `▮` on the live account row; refresh-token life shown as a 30-day fuel gauge per profile.

- [ ] **Step 1: Write the complete file** — full content below (this is the entire deliverable; copy verbatim):

```html
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Claude Account Switcher</title>
<style>
  :root {
    --bg: #171310; --surface: #211B16; --surface2: #2A2119; --border: #3A2E24;
    --text: #EDE4D8; --muted: #9A8C7D; --accent: #E8804F;
    --ok: #8FBF6F; --warn: #E3B341; --danger: #E5534B;
    --mono: "Cascadia Mono", Consolas, ui-monospace, monospace;
    --sans: "Segoe UI", system-ui, sans-serif;
  }
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { background: var(--bg); color: var(--text); font-family: var(--sans); min-height: 100vh; }
  .wrap { max-width: 760px; margin: 0 auto; padding: 32px 20px 80px; }

  /* header — shell prompt */
  header { font-family: var(--mono); margin-bottom: 6px; display: flex; align-items: baseline; gap: 10px; flex-wrap: wrap; }
  header h1 { font-size: 20px; font-weight: 600; letter-spacing: -0.5px; }
  header h1 .tilde { color: var(--accent); }
  header .srv { margin-left: auto; font-size: 12px; color: var(--muted); }
  header .srv .dot { color: var(--ok); }
  .subtitle { color: var(--muted); font-size: 13px; margin-bottom: 24px; }

  /* live strip */
  .live-strip { font-family: var(--mono); font-size: 13px; background: var(--surface); border: 1px solid var(--border); border-left: 3px solid var(--accent); padding: 12px 16px; margin-bottom: 16px; }
  .live-strip .label { color: var(--muted); margin-right: 8px; }
  .live-strip .who { color: var(--accent); font-weight: 600; }

  /* drift banner */
  .banner { display: none; background: #33241A; border: 1px solid var(--warn); padding: 14px 16px; margin-bottom: 16px; font-size: 13.5px; border-radius: 2px; }
  .banner.show { display: flex; gap: 12px; align-items: center; flex-wrap: wrap; }
  .banner .msg { flex: 1 1 260px; }
  .banner strong { color: var(--warn); }

  /* profile rows */
  .profiles { border: 1px solid var(--border); border-radius: 2px; overflow: hidden; }
  .row { display: grid; grid-template-columns: 26px 1fr auto; gap: 4px 14px; padding: 16px 18px; background: var(--surface); border-bottom: 1px solid var(--border); align-items: center; }
  .row:last-child { border-bottom: none; }
  .row.live { background: var(--surface2); }
  .cursor { font-family: var(--mono); font-size: 18px; color: var(--border); grid-row: span 2; }
  .row.live .cursor { color: var(--accent); animation: blink 1.1s steps(1) infinite; }
  @keyframes blink { 50% { opacity: 0; } }
  @media (prefers-reduced-motion: reduce) { .row.live .cursor { animation: none; } }
  .row .id { min-width: 0; }
  .row .name { font-family: var(--mono); font-weight: 700; font-size: 15px; }
  .row .meta { color: var(--muted); font-size: 12.5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .row .meta .tier { color: var(--text); background: var(--surface2); border: 1px solid var(--border); border-radius: 2px; padding: 0 6px; margin-left: 6px; font-family: var(--mono); font-size: 11px; }
  .row.live .meta .tier { background: var(--bg); }
  .actions { display: flex; gap: 8px; align-items: center; grid-row: span 2; }

  /* fuel gauge */
  .gauge { grid-column: 2; display: flex; align-items: center; gap: 10px; font-family: var(--mono); font-size: 11.5px; color: var(--muted); }
  .gauge .bar { flex: 0 1 180px; height: 5px; background: var(--bg); border: 1px solid var(--border); }
  .gauge .fill { height: 100%; background: var(--ok); }
  .gauge.warn .fill { background: var(--warn); }
  .gauge.danger .fill { background: var(--danger); }
  .gauge.danger .days { color: var(--danger); }

  /* buttons */
  button { font-family: var(--mono); font-size: 12.5px; cursor: pointer; border-radius: 2px; padding: 7px 14px; border: 1px solid var(--border); background: var(--surface2); color: var(--text); }
  button:hover { border-color: var(--accent); }
  button:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }
  button.primary { background: var(--accent); border-color: var(--accent); color: #1A120C; font-weight: 700; }
  button.primary:hover { background: #F09059; }
  button.ghost { background: none; border-color: transparent; color: var(--muted); padding: 7px 8px; }
  button.ghost:hover { color: var(--text); border-color: var(--border); }
  button.confirm { background: var(--danger); border-color: var(--danger); color: #fff; }
  button:disabled { opacity: 0.45; cursor: not-allowed; }
  .live-tag { font-family: var(--mono); font-size: 11.5px; color: var(--ok); border: 1px solid var(--ok); border-radius: 2px; padding: 6px 12px; }

  /* save bar */
  .save-bar { display: flex; gap: 10px; margin-top: 16px; }
  .save-bar input { flex: 1; background: var(--surface); border: 1px solid var(--border); border-radius: 2px; color: var(--text); font-family: var(--mono); font-size: 13px; padding: 10px 12px; }
  .save-bar input:focus-visible { outline: 2px solid var(--accent); outline-offset: -1px; }
  .save-bar input::placeholder { color: var(--muted); }

  /* empty state */
  .empty { padding: 40px 24px; text-align: center; color: var(--muted); font-size: 13.5px; background: var(--surface); line-height: 1.9; }
  .empty code, .howto code { font-family: var(--mono); background: var(--bg); border: 1px solid var(--border); padding: 1px 7px; border-radius: 2px; color: var(--accent); font-size: 12.5px; }

  /* how-to + backups */
  details { margin-top: 28px; border: 1px solid var(--border); border-radius: 2px; background: var(--surface); }
  details summary { cursor: pointer; padding: 12px 16px; font-family: var(--mono); font-size: 13px; color: var(--muted); }
  details summary:hover { color: var(--text); }
  details .inner { padding: 4px 16px 16px; font-size: 13.5px; color: var(--muted); line-height: 2.1; }
  details .inner ol { margin-left: 18px; }
  .backup-row { display: flex; align-items: center; gap: 12px; padding: 8px 0; font-family: var(--mono); font-size: 12px; border-top: 1px solid var(--border); }
  .backup-row:first-of-type { border-top: none; }
  .backup-row .id { flex: 1; color: var(--muted); overflow: hidden; text-overflow: ellipsis; }

  /* toasts */
  .toasts { position: fixed; bottom: 20px; right: 20px; display: flex; flex-direction: column; gap: 8px; z-index: 10; }
  .toast { background: var(--surface2); border: 1px solid var(--border); border-left: 3px solid var(--ok); padding: 12px 16px; font-size: 13px; max-width: 340px; border-radius: 2px; box-shadow: 0 4px 16px rgba(0,0,0,0.4); }
  .toast.error { border-left-color: var(--danger); }

  @media (max-width: 560px) {
    .row { grid-template-columns: 20px 1fr; }
    .actions { grid-row: auto; grid-column: 2; justify-content: flex-end; }
    .gauge .bar { flex-basis: 120px; }
  }
</style>
</head>
<body>
<div class="wrap">
  <header>
    <h1>claude <span class="tilde">~</span> account switcher</h1>
    <span class="srv"><span class="dot">●</span> local · 127.0.0.1</span>
  </header>
  <p class="subtitle">Save each login once. Switch accounts with one click — no re-authentication.</p>

  <div class="live-strip" id="liveStrip"><span class="label">LIVE&gt;</span><span class="who">checking…</span></div>

  <div class="banner" id="driftBanner">
    <span class="msg"><strong>New account detected:</strong> <span id="driftEmail"></span> is live but not saved yet.</span>
    <input id="driftName" placeholder="profile name" style="font-family:var(--mono);font-size:12.5px;padding:7px 10px;background:var(--bg);border:1px solid var(--border);border-radius:2px;color:var(--text);width:140px;">
    <button class="primary" onclick="saveProfile('driftName')">Save account</button>
  </div>

  <div class="profiles" id="profileList"></div>

  <div class="save-bar" id="saveBar">
    <input id="newName" placeholder="name this account (e.g. work, personal)" maxlength="40">
    <button class="primary" onclick="saveProfile('newName')">Save current account</button>
  </div>

  <details>
    <summary>+ add another account</summary>
    <div class="inner howto">
      <ol>
        <li>Open any terminal and run <code>claude /login</code> — sign in with the other account (one-time).</li>
        <li>Come back here — a "New account detected" banner appears.</li>
        <li>Name it and press <b>Save account</b>. Switch between accounts any time after that.</li>
      </ol>
    </div>
  </details>

  <details>
    <summary id="backupSummary">backups</summary>
    <div class="inner" id="backupList"></div>
  </details>
</div>
<div class="toasts" id="toasts"></div>

<script>
'use strict';
const $ = id => document.getElementById(id);
let state = null;
let confirmArm = null; // "delete:<name>" or "restore:<id>" awaiting second click

function toast(msg, isError) {
  const el = document.createElement('div');
  el.className = 'toast' + (isError ? ' error' : '');
  el.textContent = msg;
  $('toasts').appendChild(el);
  setTimeout(() => el.remove(), 4000);
}

async function api(pathname, opts) {
  const res = await fetch(pathname, opts && {
    method: opts.method, headers: { 'Content-Type': 'application/json' },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

function daysLeft(ts) { return ts ? Math.max(0, (ts - Date.now()) / 86400e3) : null; }
function esc(s) { const d = document.createElement('div'); d.textContent = s == null ? '' : String(s); return d.innerHTML; }

function render() {
  const live = state.live;
  $('liveStrip').innerHTML = live.loggedIn
    ? `<span class="label">LIVE&gt;</span><span class="who">${esc(live.email)}</span>` +
      `<span class="label"> · ${esc(live.organization || '')}` +
      (live.matchedProfile ? ` · profile: ${esc(live.matchedProfile)}` : '') + '</span>'
    : '<span class="label">LIVE&gt;</span><span class="who">not logged in</span><span class="label"> — run <b>claude /login</b> in a terminal</span>';

  const drift = live.loggedIn && !live.matchedProfile;
  $('driftBanner').classList.toggle('show', drift);
  if (drift) $('driftEmail').textContent = live.email;
  $('saveBar').style.display = drift || !state.profiles.length ? 'none' : 'flex';

  if (!state.profiles.length) {
    $('profileList').innerHTML = '<div class="empty">No saved accounts yet.<br>' +
      (live.loggedIn ? 'Name your current account below and save it to get started.' :
        'Run <code>claude /login</code> in a terminal, then save the account here.') + '</div>';
    if (live.loggedIn && !drift) $('saveBar').style.display = 'flex';
  } else {
    $('profileList').innerHTML = state.profiles.map(p => {
      const days = daysLeft(p.refreshTokenExpiresAt);
      const pct = days == null ? 100 : Math.min(100, days / 30 * 100);
      const cls = days != null && days < 3 ? 'danger' : days != null && days < 5 ? 'warn' : '';
      const gaugeText = days == null ? 'login validity unknown'
        : days <= 0 ? 'login expired — run claude /login for this account'
        : Math.round(days) + 'd of login left';
      const armed = confirmArm === 'delete:' + p.name;
      return `<div class="row${p.isLive ? ' live' : ''}">
        <span class="cursor">${p.isLive ? '▮' : '▯'}</span>
        <div class="id">
          <div class="name">${esc(p.name)}</div>
          <div class="meta">${esc(p.email)} · ${esc(p.organization || '')}<span class="tier">${esc(p.tier || '?')}</span></div>
        </div>
        <div class="actions">
          ${p.isLive ? '<span class="live-tag">LIVE NOW</span>'
            : `<button class="primary" onclick="switchTo('${esc(p.name)}')">Switch</button>`}
          <button class="ghost" title="Rename" onclick="renameProfile('${esc(p.name)}')">rename</button>
          <button class="${armed ? 'confirm' : 'ghost'}" onclick="deleteProfile('${esc(p.name)}')">${armed ? 'sure?' : 'delete'}</button>
        </div>
        <div class="gauge ${cls}"><span class="bar"><span class="fill" style="width:${pct}%"></span></span><span class="days">${esc(gaugeText)}</span></div>
      </div>`;
    }).join('');
  }
}

async function refresh() {
  try {
    state = await api('/api/state');
    render();
    await renderBackups();
  } catch (err) {
    $('liveStrip').innerHTML = '<span class="label">LIVE&gt;</span><span class="who">server unreachable</span>';
  }
}

async function saveProfile(inputId) {
  const name = $(inputId).value.trim();
  if (!name) return toast('Give the account a name first.', true);
  try {
    const res = await api('/api/profiles', { method: 'POST', body: { name } });
    toast(res.updated ? `Updated existing profile "${res.name}" (same account).` : `Saved "${res.name}".`);
    $(inputId).value = '';
    refresh();
  } catch (err) { toast(err.message, true); }
}

async function switchTo(name) {
  try {
    await api('/api/switch', { method: 'POST', body: { name } });
    toast(`Switched to "${name}". New Claude sessions use it now; running ones keep their old login until restarted.`);
    refresh();
  } catch (err) { toast(err.message, true); }
}

async function renameProfile(name) {
  const newName = prompt(`Rename "${name}" to:`, name);
  if (!newName || newName === name) return;
  try {
    await api('/api/profiles/' + encodeURIComponent(name), { method: 'PATCH', body: { newName } });
    toast(`Renamed to "${newName}".`);
    refresh();
  } catch (err) { toast(err.message, true); }
}

async function deleteProfile(name) {
  if (confirmArm !== 'delete:' + name) {
    confirmArm = 'delete:' + name;
    render();
    setTimeout(() => { if (confirmArm === 'delete:' + name) { confirmArm = null; render(); } }, 3000);
    return;
  }
  confirmArm = null;
  try {
    await api('/api/profiles/' + encodeURIComponent(name), { method: 'DELETE' });
    toast(`Deleted "${name}".`);
    refresh();
  } catch (err) { toast(err.message, true); }
}

async function renderBackups() {
  const ids = await api('/api/backups');
  $('backupSummary').textContent = `backups (${ids.length})`;
  $('backupList').innerHTML = ids.length ? ids.map(id => {
    const armed = confirmArm === 'restore:' + id;
    return `<div class="backup-row"><span class="id">${esc(id)}</span>` +
      `<button class="${armed ? 'confirm' : 'ghost'}" onclick="restoreBackup('${esc(id)}')">${armed ? 'sure?' : 'restore'}</button></div>`;
  }).join('') : 'No backups yet. One is created automatically before every switch.';
}

async function restoreBackup(id) {
  if (confirmArm !== 'restore:' + id) {
    confirmArm = 'restore:' + id;
    renderBackups();
    setTimeout(() => { if (confirmArm === 'restore:' + id) { confirmArm = null; renderBackups(); } }, 3000);
    return;
  }
  confirmArm = null;
  try {
    await api('/api/restore', { method: 'POST', body: { id } });
    toast('Backup restored.');
    refresh();
  } catch (err) { toast(err.message, true); }
}

document.addEventListener('keydown', e => {
  if (e.key === 'Enter' && (e.target.id === 'newName' || e.target.id === 'driftName')) saveProfile(e.target.id);
});

refresh();
setInterval(refresh, 15000);
</script>
</body>
</html>
```

- [ ] **Step 2: Verify in browser** — start `node server.js`, open `http://localhost:4789`; confirm: live strip shows the logged-in email, current account can be saved, row renders with gauge and LIVE NOW tag. Take a screenshot (Chrome DevTools MCP) and self-critique against the design direction.

---

### Task 6: Real-machine verification, launcher, docs, hygiene

**Files:**
- Create: `d:\kd\multi-account\start.cmd`
- Create: `d:\kd\multi-account\.gitignore`
- Create: `d:\kd\multi-account\README.md`

**Interfaces:**
- Consumes: everything above.
- Produces: double-clickable launcher, ignore rules, user docs.

- [ ] **Step 1: `start.cmd`**

```bat
@echo off
start "" http://localhost:4789
node "%~dp0server.js"
```

- [ ] **Step 2: `.gitignore`**

```
profiles.json
backups/
node_modules/
```

- [ ] **Step 3: `README.md`** — plain-English usage doc covering: what it does, `node server.js` / `start.cmd`, the add-second-account flow (`claude /login` once → drift banner → save), the sync-back behavior, the running-sessions caveat (old sessions keep old login until restarted and may overwrite the live file when they self-refresh — the drift banner catches this), and a security warning that `profiles.json` holds real tokens and must never be committed or shared.

- [ ] **Step 4: Full test suite** — `node --test server.test.js` → all pass.

- [ ] **Step 5: Live verification on the real machine (careful — real credentials):**
  1. `node server.js`, open UI. Live strip must show `admin@superworks.com`.
  2. Save current account under a name. Check `profiles.json` contains it and a matching `accountUuid`.
  3. Run `claude /status` (or `claude` briefly) in a fresh terminal to confirm Claude still works — proves the tool didn't corrupt anything.
  4. Full switch round-trip needs a second account login (only the user can OAuth) — demonstrate switch by saving, then switching to the same single profile (a no-op switch exercises the whole write path: sync-back, backup, atomic writes), then `claude /status` again.
  5. Confirm a backup appeared in `backups/`.

## Self-Review (done at planning time)

- **Spec coverage:** paths/CLAUDE_CONFIG_DIR (T1), save/dedupe (T2), sync-back + backup + switch + restore + expiry guard + corrupt-file abort (T3), full API (T4), UI incl. drift banner, gauge, empty states, toasts, reduced-motion (T5), security/docs/launcher (T6). Restore-at-capacity pruning bug preempted with a test.
- **Placeholder scan:** clean — full code everywhere; README content enumerated.
- **Type consistency:** state shape in T3 matches UI consumption in T5 (`live.matchedProfile`, `profiles[].refreshTokenExpiresAt`, etc.); route shapes in T4 match `api()` calls in T5.
