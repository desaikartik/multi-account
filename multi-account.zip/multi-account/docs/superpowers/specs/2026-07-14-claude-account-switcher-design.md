# Claude Code Account Switcher — Design Spec

**Date:** 2026-07-14
**Status:** Approved by user

## Problem

The user runs Claude Code with multiple Claude accounts (Team/Max plans). When one account nears its usage limit, they currently run `claude /login` and re-authenticate through the browser OAuth flow every time. They want: authenticate each account **once**, then switch the live account with a **single button click** — while running Claude sessions keep working uninterrupted and new usage flows to the switched account.

## How switching works (mechanism)

Claude Code on Windows stores OAuth credentials in:

- `%USERPROFILE%\.claude\.credentials.json` — `{ claudeAiOauth: { accessToken, refreshToken, expiresAt, refreshTokenExpiresAt, scopes, subscriptionType, rateLimitTier } }`
- `%USERPROFILE%\.claude.json` — `oauthAccount` object (accountUuid, emailAddress, organizationUuid, organizationName, displayName, seat/billing metadata) plus unrelated app state.

Both files must respect `CLAUDE_CONFIG_DIR` if set (`.credentials.json` lives inside it; `.claude.json` sits next to it in the home directory by default).

A profile = a snapshot of `claudeAiOauth` + `oauthAccount`. Switching = writing a saved profile's `claudeAiOauth` back into `.credentials.json` and patching only the `oauthAccount` key inside `.claude.json` (all other keys untouched). No OAuth flow needed: the saved `refreshToken` stays valid ~30 days and Claude Code silently refreshes access tokens with it.

**Critical rule — sync-back:** Claude Code rewrites `.credentials.json` whenever it refreshes a token. So before every switch, the switcher must copy the live credentials back into whichever saved profile matches the live `accountUuid`. Without this, saved snapshots go stale and their refresh tokens may be rotated out.

## Architecture

Three files, zero npm dependencies (Node v22 built-ins only):

| File | Purpose |
|---|---|
| `server.js` | HTTP server on `127.0.0.1:4789`. Serves the UI and a JSON API. All file I/O and switching logic. |
| `public/index.html` | Single-page UI (inline CSS/JS). Dark theme, profile cards, toasts. |
| `profiles.json` | Local store (auto-created). Contains real tokens — must stay local. |

Plus `backups/` (auto-created, last 10 pre-switch backups) and `.gitignore` covering `profiles.json` and `backups/`.

### profiles.json schema

```json
{
  "activeProfile": "work",
  "profiles": {
    "work": {
      "credentials": { "...claudeAiOauth fields..." : "" },
      "account": { "...oauthAccount fields..." : "" },
      "savedAt": "ISO-8601",
      "lastUsedAt": "ISO-8601"
    }
  }
}
```

### API

- `GET /api/state` → `{ live: { account, expiresAt, refreshTokenExpiresAt, matchedProfile|null, loggedIn }, profiles: [...with expiry status...], activeProfile }`
- `POST /api/profiles` `{name}` → snapshot live account as a named profile. If live `accountUuid` already exists under another name, update that profile instead and report it (no duplicates).
- `POST /api/switch` `{name}` → sync-back live → backup both files → write profile credentials + patch `oauthAccount` → set `activeProfile`.
- `PATCH /api/profiles/:name` `{newName}` → rename.
- `DELETE /api/profiles/:name` → delete (blocked with 409 if it is the only copy of the currently live account? No — allowed, but UI confirms).
- `GET /api/backups` → list; `POST /api/restore` `{id}` → restore a backup pair.

### Flows

1. **Save current account:** button → name prompt → `POST /api/profiles`.
2. **Add another account:** UI shows guided steps — run `claude /login` in any terminal (one-time OAuth for that account), UI's drift detection notices the new unknown account, user clicks "Save current account".
3. **Switch:** single click on a profile card → `POST /api/switch`. Running sessions continue on the old account's in-memory token; new sessions/requests use the new account.

### UI features

- Profile cards: name, email, org, plan tier, **refresh-token expiry countdown** (red warning under 5 days: "needs a real `claude /login` renew"), ACTIVE badge, Switch / Rename / Delete.
- Live status bar: which account is live right now, detected via `accountUuid` match.
- **Drift detection:** live credentials match no saved profile → banner "Unknown account is live — save it?" (this is also the add-second-account path).
- Backups panel: list of last 10, one-click restore.
- Poll `GET /api/state` every 15 s; toasts for all actions.

## Error handling

- `.credentials.json` or `oauthAccount` missing → UI shows "Not logged in — run `claude /login`"; save/switch disabled.
- Switch to a profile with expired `refreshTokenExpiresAt` → 409 with message "This account's login expired — run `claude /login` for it once, then re-save."
- All writes atomic: write temp file in the same directory, then rename over the target.
- `.claude.json` parse failure → abort switch, never write a corrupted file.
- Known limitation (accepted): after a switch, an old running session may later refresh its own token and overwrite `.credentials.json`. Drift detection surfaces this immediately; one click switches back.

## Security

- Server binds `127.0.0.1` only.
- Tokens never logged; API responses include expiry metadata but the UI never displays token strings.
- `.gitignore` prevents committing `profiles.json` / `backups/`.

## Testing

- Manual verification checklist (no test framework for this mini-project):
  1. Save current account → appears in profiles.json with correct email.
  2. Switch to another saved profile → `.credentials.json` and `oauthAccount` reflect it; backup created.
  3. Sync-back: modify live expiresAt, switch away, confirm the matching profile absorbed the newer credentials.
  4. Drift: replace live credentials with an unmatched accountUuid → banner appears.
  5. `claude` CLI in a new terminal reports the switched account (`/status`).
