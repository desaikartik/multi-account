@echo off
title Claude Account Switcher - Setup
echo.
echo  Claude Account Switcher - one-time setup
echo  =========================================
echo.

echo  [1/3] Checking Node.js...
where node >nul 2>nul
if errorlevel 1 (
  echo        Node.js not found. Installing with winget...
  winget install OpenJS.NodeJS.LTS --accept-source-agreements --accept-package-agreements
  if errorlevel 1 (
    echo.
    echo        Automatic install failed. Please install Node.js from:
    echo        https://nodejs.org  ^(choose "LTS"^)
    echo        Then run setup.cmd again.
    echo.
    pause
    exit /b 1
  )
  echo        Installed. If the app does not start below, close this
  echo        window and run setup.cmd once more.
) else (
  for /f "delims=" %%v in ('node --version') do echo        Found Node.js %%v
)

echo  [2/3] Creating Desktop shortcut...
powershell -NoProfile -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut([Environment]::GetFolderPath('Desktop') + '\Claude Account Switcher.lnk'); $s.TargetPath = '%~dp0start.cmd'; $s.WorkingDirectory = '%~dp0'; $s.IconLocation = 'shell32.dll,167'; $s.Save()" >nul 2>nul
if errorlevel 1 (echo        Could not create the shortcut - you can still use start.cmd) else (echo        Done - "Claude Account Switcher" is on your Desktop)

echo  [3/3] Starting the app...
echo.
echo  Setup complete! The dashboard opens in a moment.
echo  Tip: turn on "Start with Windows" inside Settings.
echo.
call "%~dp0start.cmd"
