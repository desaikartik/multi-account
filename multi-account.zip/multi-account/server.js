#!/usr/bin/env node
'use strict';
const files = require('./lib/files');
const profiles = require('./lib/profiles');
const switcher = require('./lib/switcher');
const usage = require('./lib/usage');
const autostart = require('./lib/autostart');
const events = require('./lib/events');
const { createLogger } = require('./lib/log');
const server = require('./lib/server');

module.exports = {
  ...files, ...profiles, ...switcher, ...usage, ...autostart, ...events, ...server,
};

async function main() {
  const paths = files.getPaths();
  const port = Number(process.env.PORT) || 4789;
  const logger = createLogger(paths.log);

  process.on('uncaughtException', err => {
    logger.error('uncaughtException: ' + (err.stack || err));
    process.exit(1);
  });
  process.on('unhandledRejection', err => logger.error('unhandledRejection: ' + (err && err.stack || err)));

  const httpServer = server.createServer(paths, { logger });
  httpServer.on('error', async err => {
    if (err.code !== 'EADDRINUSE') {
      logger.error('server error: ' + err.message);
      process.exit(1);
    }
    try {
      const res = await fetch(`http://127.0.0.1:${port}/api/health`, { signal: AbortSignal.timeout(5000) });
      const health = await res.json();
      if (health.app === server.APP_NAME) {
        console.log(`Already running at http://localhost:${port}`);
        process.exit(0);
      }
    } catch {}
    logger.error(`Port ${port} is used by another program. Start with a different port, e.g.:  set PORT=4790 && node server.js`);
    process.exit(1);
  });
  httpServer.listen(port, '127.0.0.1', () => {
    logger.info(`Claude Account Switcher v${server.VERSION} running at http://localhost:${port}`);
  });
}

if (require.main === module) main();
