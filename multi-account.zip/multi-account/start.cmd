@echo off
cd /d "%~dp0"
start "Claude Account Switcher Server" /min cmd /c "node server.js"
timeout /t 1 /nobreak >nul
start "" msedge --app=http://localhost:4789
