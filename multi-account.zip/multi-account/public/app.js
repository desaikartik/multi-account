'use strict';
const $ = id => document.getElementById(id);
const AVATAR_COLORS = ['#C15F3C', '#5B7DB1', '#1F7A3D', '#8E5BB1', '#B15B7D', '#946300'];
let state = null;
let lastStateJson = null;
let usage = null;
let lastUsageJson = null;
let pendingName = null;
let pendingBackup = null;
let currentView = 'dashboard';

function toast(msg, isError) {
  const el = document.createElement('div');
  el.className = 'toast' + (isError ? ' error' : '');
  el.textContent = msg;
  $('toasts').appendChild(el);
  setTimeout(() => el.remove(), 4500);
}

async function api(pathname, opts) {
  const res = await fetch(pathname, opts && {
    method: opts.method, headers: { 'Content-Type': 'application/json' },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Something went wrong. Please try again.');
  return data;
}

function esc(s) { const d = document.createElement('div'); d.textContent = s == null ? '' : String(s); return d.innerHTML; }
function escAttr(s) { return esc(s).replace(/"/g, '&quot;').replace(/'/g, '&#39;'); }
function avatarColor(name) {
  let h = 0; for (const c of String(name)) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  return AVATAR_COLORS[h % AVATAR_COLORS.length];
}
function daysLeft(ts) { return ts ? Math.max(0, (ts - Date.now()) / 86400e3) : null; }

const VIEW_TITLES = { dashboard: 'Dashboard', activity: 'Activity', backups: 'Backups', settings: 'Settings', help: 'How it works' };
function showView(view) {
  currentView = view;
  for (const v of Object.keys(VIEW_TITLES)) $('view-' + v).hidden = v !== view;
  document.querySelectorAll('.nav-item').forEach(n => n.classList.toggle('active', n.dataset.view === view));
  $('pageTitle').textContent = VIEW_TITLES[view];
  if (view === 'backups') loadBackups();
  if (view === 'activity') loadEvents();
}

function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  localStorage.setItem('cas-theme', theme);
  $('themeBtn').textContent = theme === 'dark' ? '☀' : '🌙';
  $('themeBtn').title = theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode';
}
function toggleTheme() {
  applyTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
}

function validityHtml(ts) {
  const days = daysLeft(ts);
  if (days == null) return '';
  if (days <= 0) return '<div class="validity danger"><span class="dot"></span>Login expired — sign in with this account once, then save it again</div>';
  const d = Math.round(days);
  if (days < 5) return `<div class="validity warn"><span class="dot"></span>Renew soon — login valid for ${d} more day${d === 1 ? '' : 's'}</div>`;
  return `<div class="validity"><span class="dot"></span>Login valid for ${d} days</div>`;
}

function fmtReset(iso) {
  const d = new Date(iso);
  if (isNaN(d)) return '';
  const time = d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  return d.toDateString() === new Date().toDateString()
    ? 'resets ' + time
    : 'resets ' + d.toLocaleDateString([], { weekday: 'short' }) + ' ' + time;
}

function fmtWhen(iso) {
  const d = new Date(iso);
  if (isNaN(d)) return '';
  const time = d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  return d.toDateString() === new Date().toDateString()
    ? 'Today ' + time
    : d.toLocaleDateString([], { month: 'short', day: 'numeric' }) + ' ' + time;
}

function usageRow(label, bucket) {
  if (!bucket || bucket.utilization == null) return '';
  const pct = Math.round(bucket.utilization);
  const cls = pct >= 90 ? 'danger' : pct >= 70 ? 'warn' : '';
  return `<div class="u-row ${cls}"><span class="u-label">${label}</span>
    <span class="u-bar"><span class="u-fill" style="width:${Math.min(100, pct)}%"></span></span>
    <span class="u-val">${pct}%</span><span>${bucket.resetsAt ? fmtReset(bucket.resetsAt) : ''}</span></div>`;
}

function usageHtml(name) {
  const u = usage && usage.profiles && usage.profiles[name];
  if (!u) return '';
  if (u.error) return `<div class="u-note">Usage: ${esc(u.error)}</div>`;
  const rows = usageRow('5-hour', u.fiveHour) + usageRow('Weekly', u.sevenDay) +
    (u.models || []).map(m => usageRow(esc(m.label), m)).join('');
  return rows ? `<div class="usage">${rows}</div>` : '';
}

function usageBuckets(u) {
  if (!u || u.error) return [];
  const buckets = [];
  if (u.fiveHour) buckets.push(['5-hour', u.fiveHour]);
  if (u.sevenDay) buckets.push(['weekly', u.sevenDay]);
  for (const m of u.models || []) buckets.push([m.label + ' weekly', m]);
  return buckets;
}

function worstBucket(u) {
  let worst = null;
  for (const [label, b] of usageBuckets(u)) {
    if (b.utilization != null && (!worst || b.utilization > worst.pct)) {
      worst = { label, pct: Math.round(b.utilization), resetsAt: b.resetsAt };
    }
  }
  return worst;
}

function resetTime(b) {
  const t = b && b.resetsAt ? Date.parse(b.resetsAt) : NaN;
  return isNaN(t) ? Infinity : t;
}

function pickBestAlternative(activeName) {
  const candidates = [];
  for (const p of state.profiles) {
    if (p.isLive || p.damaged) continue;
    const w = worstBucket(usage.profiles[p.name]);
    if (w) candidates.push({ name: p.name, w });
  }
  if (!candidates.length) return null;
  const headroom = candidates.filter(c => c.w.pct < 90);
  if (headroom.length) {
    headroom.sort((a, b) => a.w.pct - b.w.pct || resetTime(a.w) - resetTime(b.w));
    return { pick: headroom[0], allFull: false };
  }
  candidates.sort((a, b) => resetTime(a.w) - resetTime(b.w) || a.w.pct - b.w.pct);
  return { pick: candidates[0], allFull: true };
}

function cardHtml(p) {
  const initial = (p.name || '?').trim()[0].toUpperCase();
  return `<div class="card${p.isLive ? ' active' : ''}">
    <div class="avatar" style="background:${avatarColor(p.name)}">${esc(initial)}</div>
    <div class="info">
      <div class="name">${esc(p.name)}
        ${p.isLive ? '<span class="chip green">✓ Active now</span>' : ''}
        ${p.tier ? `<span class="chip">${esc(p.tier)}</span>` : ''}
      </div>
      <div class="email">${esc(p.email)}${p.organization ? ' · ' + esc(p.organization) : ''}</div>
      ${validityHtml(p.refreshTokenExpiresAt)}
      ${usageHtml(p.name)}
    </div>
    <div class="side">
      ${p.isLive ? '' : `<button class="btn primary" data-action="switch" data-name="${escAttr(p.name)}">Switch</button>`}
      <div class="mini-actions">
        <button data-action="rename" data-name="${escAttr(p.name)}">Rename</button>
        <button data-action="remove" data-name="${escAttr(p.name)}">Remove</button>
      </div>
    </div>
  </div>`;
}

function kpiTile(label, value, sub, opts = {}) {
  const meter = opts.pct != null
    ? `<span class="k-meter"><span class="k-fill" style="width:${Math.min(100, opts.pct)}%"></span></span>` : '';
  return `<div class="kpi ${opts.cls || ''}">
    <div class="k-label">${label}</div>
    <div class="k-value ${opts.small ? 'small' : ''}">${value}</div>
    <div class="k-sub">${sub || '&nbsp;'}</div>${meter}
  </div>`;
}

function usageCls(pct) { return pct == null ? '' : pct >= 90 ? 'danger' : pct >= 70 ? 'warn' : ''; }

function renderKpis() {
  const live = state.live;
  const activeName = live.matchedProfile;
  const u = activeName && usage && usage.profiles[activeName];
  const err = u && u.error;
  const worst = u && !err ? worstBucket(u) : null;
  const fh = u && !err && u.fiveHour ? Math.round(u.fiveHour.utilization) : null;
  const pending = err ? 'Unavailable right now' : 'checking…';
  const days = daysLeft(live.refreshTokenExpiresAt);
  $('kpiRow').innerHTML =
    kpiTile('Active account', activeName ? esc(activeName) : '—',
      live.loggedIn ? esc(live.email) : 'Not signed in', { small: true }) +
    kpiTile('Nearest limit', worst ? worst.pct + '%' : '—',
      worst ? esc(worst.label) + (worst.resetsAt ? ' · ' + fmtReset(worst.resetsAt) : '') : pending,
      { pct: worst ? worst.pct : null, cls: worst ? usageCls(worst.pct) : '' }) +
    kpiTile('5-hour session', fh != null ? fh + '%' : '—',
      fh != null && u.fiveHour.resetsAt ? fmtReset(u.fiveHour.resetsAt) : pending,
      { pct: fh, cls: usageCls(fh) }) +
    kpiTile('Login valid', days != null ? Math.round(days) + ' days' : '—',
      days != null && days < 5 ? 'Renews on next sign-in' : 'Renews automatically',
      { cls: days != null && days < 5 ? 'warn' : '' });
}

function renderTopbar() {
  const live = state.live;
  if (!live.loggedIn) {
    $('liveChip').innerHTML = '<span class="mini-avatar">?</span><span class="who">Not signed in</span>';
    return;
  }
  const name = live.matchedProfile || live.email;
  $('liveChip').innerHTML =
    `<span class="mini-avatar" style="background:${avatarColor(name)}">${esc(String(name)[0].toUpperCase())}</span>` +
    `<span class="who">${esc(live.email)}</span><span class="status">● Active</span>`;
}

function renderLimitNotice() {
  const notice = $('limitNotice');
  if (!state || !usage) { notice.classList.remove('show'); return; }
  const activeName = state.live.matchedProfile;
  const worst = activeName ? worstBucket(usage.profiles[activeName]) : null;
  if (!worst || worst.pct < 90) { notice.classList.remove('show'); return; }

  const alt = pickBestAlternative(activeName);
  $('limitBody').innerHTML = `"<b>${esc(activeName)}</b>" has used <b>${worst.pct}%</b> of its ${esc(worst.label)} limit` +
    (worst.resetsAt ? ` (${fmtReset(worst.resetsAt)})` : '') + '.';

  if (!alt) {
    $('limitActions').innerHTML = '<span class="notice-note">Add another account to keep working.</span>';
  } else if (alt.allFull) {
    const w = alt.pick.w;
    $('limitActions').innerHTML =
      `<button class="btn primary" data-action="switch" data-name="${escAttr(alt.pick.name)}">Switch to ${esc(alt.pick.name)} (${esc(w.label)} at ${w.pct}%)</button>` +
      `<span class="notice-note">Every saved account is near a limit. "${esc(alt.pick.name)}" frees up soonest${w.resetsAt ? ` — ${esc(w.label)} ${esc(fmtReset(w.resetsAt))}` : ''}.</span>`;
  } else {
    const w = alt.pick.w;
    $('limitActions').innerHTML =
      `<button class="btn primary" data-action="switch" data-name="${escAttr(alt.pick.name)}">Switch to ${esc(alt.pick.name)} (${esc(w.label)} at ${w.pct}%)</button>` +
      `<span class="notice-note">Its most-used limit is only ${w.pct}% — plenty of room.</span>`;
  }
  notice.classList.add('show');
}

function render() {
  const live = state.live;
  const drift = live.loggedIn && !live.matchedProfile;
  $('driftNotice').classList.toggle('show', drift);
  if (drift) {
    const first = !state.profiles.length;
    $('driftTitle').textContent = first ? 'Save your account' : 'New sign-in found';
    $('driftBody').innerHTML = (first
      ? `You're signed in as <b>${esc(live.email)}</b>. Save it with a name to start switching accounts with one click.`
      : `You're now signed in as <b>${esc(live.email)}</b>, but this account isn't saved here yet. Save it so you can switch to it anytime.`);
  }

  $('accountCount').textContent = state.profiles.length ? '(' + state.profiles.length + ')' : '';

  if (!state.profiles.length) {
    $('content').innerHTML = `<div class="empty"><div class="big">👋</div>` +
      (live.loggedIn
        ? `<b>Welcome!</b> You're signed in as <b>${esc(live.email)}</b>.<br>Save this account above to start switching with one click.`
        : `<b>No Claude login found on this computer.</b><br>Open a terminal, run <code>claude /login</code> and sign in.<br>Then come back here to save the account.`) + '</div>';
  } else {
    const activeCards = state.profiles.filter(p => p.isLive);
    const otherCards = state.profiles.filter(p => !p.isLive);
    $('content').innerHTML = activeCards.map(cardHtml).join('') + otherCards.map(cardHtml).join('') +
      `<button class="add-card" onclick="openModal('addModal')">+ Add another account</button>`;
  }
  renderKpis();
  renderTopbar();
  renderLimitNotice();
}

function renderAddModal() {
  if (!$('addModal').classList.contains('show') || !state) return;
  const drift = state.live.loggedIn && !state.live.matchedProfile;
  $('addSteps').style.display = drift ? 'none' : '';
  $('addFound').style.display = drift ? '' : 'none';
  if (drift) $('foundEmail').textContent = state.live.email;
}

async function refresh(force) {
  try {
    const fresh = await api('/api/state');
    const json = JSON.stringify(fresh);
    if (!force && json === lastStateJson) return;
    lastStateJson = json;
    state = fresh;
    $('autostartToggle').checked = Boolean(state.autostart);
    render();
    renderAddModal();
    if (currentView === 'dashboard' || currentView === 'activity') loadEvents();
    if (currentView === 'backups') loadBackups();
  } catch (err) {
    lastStateJson = null;
    const isNetwork = err instanceof TypeError;
    $('content').innerHTML = isNetwork
      ? '<div class="empty"><div class="big">🔌</div><b>Can\'t reach the app.</b><br>Start it again with <code>start.cmd</code> or <code>node server.js</code>, then reload this page.</div>'
      : `<div class="empty"><div class="big">⚠️</div><b>Something needs attention.</b><br>${esc(err.message)}</div>`;
  }
}

async function refreshUsage() {
  try {
    const fresh = await api('/api/usage');
    const json = JSON.stringify(fresh);
    if (json === lastUsageJson) return;
    lastUsageJson = json;
    usage = fresh;
    if (state) render();
  } catch {}
}

async function saveProfile(inputId) {
  const name = $(inputId).value.trim();
  if (!name) { toast('Please type a name for this account first.', true); return false; }
  try {
    const res = await api('/api/profiles', { method: 'POST', body: { name } });
    toast(res.updated ? `This account was already saved as "${res.name}" — updated it.` : `Account saved as "${res.name}".`);
    $(inputId).value = '';
    refresh();
    return true;
  } catch (err) { toast(err.message, true); return false; }
}

async function saveFromAdd() {
  if (await saveProfile('addName')) closeModals();
}

async function switchTo(name, btn) {
  if (btn) { btn.disabled = true; btn.textContent = 'Switching…'; }
  try {
    await api('/api/switch', { method: 'POST', body: { name } });
    toast(`Switched to "${name}". New Claude windows will use this account.`);
    await refresh();
  } catch (err) {
    toast(err.message, true);
    if (btn) { btn.disabled = false; btn.textContent = 'Switch'; }
  }
}

async function openLogin() {
  try {
    await api('/api/open-login', { method: 'POST' });
    $('addWaiting').style.display = '';
    toast('A sign-in window is opening — complete the login there.');
  } catch (err) { toast(err.message, true); }
}

function openModal(id) { closeModals(); $(id).classList.add('show'); if (id === 'addModal') renderAddModal(); }
function closeModals() { document.querySelectorAll('.overlay').forEach(o => o.classList.remove('show')); }

function openRename(name) {
  pendingName = name;
  $('renameInput').value = name;
  openModal('renameModal');
  $('renameInput').focus();
}
async function confirmRename() {
  const newName = $('renameInput').value.trim();
  if (!newName || newName === pendingName) return closeModals();
  try {
    await api('/api/profiles/' + encodeURIComponent(pendingName), { method: 'PATCH', body: { newName } });
    toast(`Renamed to "${newName}".`);
    closeModals(); refresh(true);
  } catch (err) { toast(err.message, true); }
}

function openRemove(name) {
  pendingName = name;
  $('removeText').innerHTML = `"<b>${esc(name)}</b>" will be removed from this list. To add it back later, you'll need to sign in with it once. Your Claude account itself is not affected.`;
  openModal('removeModal');
}
async function confirmRemove() {
  try {
    await api('/api/profiles/' + encodeURIComponent(pendingName), { method: 'DELETE' });
    toast(`Removed "${pendingName}".`);
    closeModals(); refresh(true);
  } catch (err) { toast(err.message, true); }
}

async function loadBackups() {
  try {
    const ids = await api('/api/backups');
    $('backupItems').innerHTML = ids.length ? ids.map(id => {
      const m = id.match(/^(\d{4}-\d{2}-\d{2})T(\d{2})-(\d{2})/);
      const when = m ? `${m[1]} at ${m[2]}:${m[3]}` : id;
      return `<div class="backup-item"><span class="when">${esc(when)}</span>
        <button class="btn secondary" style="padding:6px 14px;font-size:12.5px" data-action="restore" data-id="${escAttr(id)}">Restore</button></div>`;
    }).join('') : '<p class="sub">No backups yet. One is created automatically before every switch.</p>';
  } catch (err) { toast(err.message, true); }
}
function openRestore(id) { pendingBackup = id; openModal('restoreModal'); }
async function confirmRestore() {
  try {
    await api('/api/restore', { method: 'POST', body: { id: pendingBackup } });
    toast('Backup restored.');
    closeModals(); loadBackups(); refresh(true);
  } catch (err) { toast(err.message, true); }
}

const EVENT_LABELS = {
  switched: e => ['🔁', `Switched to <b>${esc(e.name)}</b>` + (e.email ? ` (${esc(e.email)})` : '')],
  saved: e => ['➕', `Saved account <b>${esc(e.name)}</b>`],
  updated: e => ['♻️', `Updated saved login for <b>${esc(e.name)}</b>`],
  removed: e => ['🗑️', `Removed <b>${esc(e.name)}</b>`],
  restored: e => ['⏪', `Restored a backup`],
  imported: e => ['📥', `Imported accounts (${e.added || 0} added, ${e.updated || 0} updated)`],
  exported: e => ['📤', `Exported all accounts to a file`],
};
function renderEventList(container, events, limit, compact) {
  if (!container) return;
  const list = events.slice(0, limit);
  if (!list.length) {
    container.innerHTML = `<p class="sub">${compact ? 'No activity yet.' : 'Nothing yet. Switches, saves, and restores will show up here.'}</p>`;
    return;
  }
  container.innerHTML = list.map(e => {
    const [icon, text] = (EVENT_LABELS[e.type] || (() => ['•', esc(e.type)]))(e);
    const when = esc(fmtWhen(e.ts));
    return compact
      ? `<div class="event-item compact"><span class="e-icon">${icon}</span><span class="e-text">${text}<span class="e-sub">${when}</span></span></div>`
      : `<div class="event-item"><span class="e-icon">${icon}</span><span class="e-text">${text}</span><span class="e-time">${when}</span></div>`;
  }).join('');
}

async function loadEvents() {
  try {
    const events = await api('/api/events');
    renderEventList($('eventItems'), events, 30, false);
    renderEventList($('dashActivity'), events, 6, true);
  } catch (err) { toast(err.message, true); }
}

async function toggleAutostart(checkbox) {
  try {
    const res = await api('/api/autostart', { method: 'POST', body: { enabled: checkbox.checked } });
    toast(res.enabled ? 'The switcher will now start automatically with Windows.' : 'Automatic start turned off.');
  } catch (err) {
    checkbox.checked = !checkbox.checked;
    toast(err.message, true);
  }
}

async function exportAccounts() {
  try {
    const res = await api('/api/export', { method: 'POST' });
    toast(`Saved ${res.accounts} account${res.accounts === 1 ? '' : 's'} to ${res.file}. Keep that file private — it contains your real logins.`);
  } catch (err) { toast(err.message, true); }
}

async function importAccounts(input) {
  const file = input.files && input.files[0];
  input.value = '';
  if (!file) return;
  try {
    const data = JSON.parse(await file.text());
    const res = await api('/api/import', { method: 'POST', body: data });
    toast(`Import done — ${res.added} added, ${res.updated} updated, ${res.skipped} skipped.`);
    refresh(true);
  } catch (err) { toast(err.message === 'Unexpected end of JSON input' ? 'That file is not a valid export.' : err.message, true); }
}

function copyCmd(btn) {
  navigator.clipboard.writeText('claude /login').then(() => {
    btn.textContent = 'Copied!';
    setTimeout(() => { btn.textContent = 'Copy'; }, 1500);
  });
}

document.addEventListener('click', e => {
  const nav = e.target.closest('.nav-item');
  if (nav) return showView(nav.dataset.view);
  const btn = e.target.closest('button[data-action]');
  if (!btn) return;
  const { action, name, id } = btn.dataset;
  if (action === 'switch') switchTo(name, btn);
  if (action === 'rename') openRename(name);
  if (action === 'remove') openRemove(name);
  if (action === 'restore') openRestore(id);
});

document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeModals();
  if (e.key === 'Enter') {
    if (e.target.id === 'driftName') saveProfile('driftName');
    if (e.target.id === 'renameInput') confirmRename();
    if (e.target.id === 'addName') saveFromAdd();
  }
});
document.querySelectorAll('.overlay').forEach(o => {
  o.addEventListener('click', e => { if (e.target === o) closeModals(); });
});

applyTheme(localStorage.getItem('cas-theme') || 'light');
window.addEventListener('focus', () => { refresh(); refreshUsage(); });
refresh();
refreshUsage();
setInterval(() => refresh(), 5000);
setInterval(() => refreshUsage(), 60000);
setInterval(() => refresh(true), 600000);
