'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const app = require('./server.js');

function makeTmpEnv() {
  const home = fs.mkdtempSync(path.join(os.tmpdir(), 'switcher-test-'));
  const dataDir = path.join(home, 'switcher-data');
  fs.mkdirSync(dataDir);
  fs.mkdirSync(path.join(home, '.claude'));
  return app.getPaths({ SWITCHER_HOME: home, SWITCHER_DATA_DIR: dataDir });
}

function writeFakeLogin(paths, letter, opts = {}) {
  const home = path.dirname(paths.claudeJson);
  fs.writeFileSync(paths.credentials, JSON.stringify({
    claudeAiOauth: {
      accessToken: 'access-' + letter + (opts.tag || ''),
      refreshToken: 'refresh-' + letter + (opts.tag || ''),
      expiresAt: Date.now() + 3600e3,
      refreshTokenExpiresAt: opts.refreshTokenExpiresAt ?? Date.now() + 30 * 86400e3,
      scopes: ['user:inference'],
      subscriptionType: 'team',
      rateLimitTier: 'default_tier',
    },
  }));
  fs.writeFileSync(paths.claudeJson, JSON.stringify({
    unrelatedKey: 'preserve-me',
    oauthAccount: {
      accountUuid: 'uuid-' + letter,
      emailAddress: letter.toLowerCase() + '@test.com',
      organizationName: 'Org ' + letter,
      displayName: 'User ' + letter,
    },
  }));
  return home;
}

test('getPaths honors SWITCHER_HOME and SWITCHER_DATA_DIR', () => {
  const p = app.getPaths({ SWITCHER_HOME: '/tmp/h', SWITCHER_DATA_DIR: '/tmp/d' });
  assert.ok(p.credentials.includes(path.join('h', '.claude', '.credentials.json')));
  assert.ok(p.claudeJson.includes(path.join('h', '.claude.json')));
  assert.ok(p.profiles.includes(path.join('d', 'profiles.json')));
  assert.ok(p.backups.includes(path.join('d', 'backups')));
});

test('getPaths honors CLAUDE_CONFIG_DIR for credentials only', () => {
  const p = app.getPaths({ SWITCHER_HOME: '/tmp/h', SWITCHER_DATA_DIR: '/tmp/d', CLAUDE_CONFIG_DIR: '/tmp/cfg' });
  assert.ok(p.credentials.includes(path.join('cfg', '.credentials.json')));
  assert.ok(p.claudeJson.includes(path.join('h', '.claude.json')));
});

test('readLive returns credentials and account from live files', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  const live = app.readLive(paths);
  assert.equal(live.credentials.accessToken, 'access-A');
  assert.equal(live.account.emailAddress, 'a@test.com');
});

test('readLive returns nulls when files are missing', () => {
  const paths = makeTmpEnv();
  const live = app.readLive(paths);
  assert.equal(live.credentials, null);
  assert.equal(live.account, null);
});

test('atomicWrite replaces existing file content', () => {
  const paths = makeTmpEnv();
  const f = path.join(path.dirname(paths.profiles), 'x.json');
  app.atomicWrite(f, '{"a":1}');
  app.atomicWrite(f, '{"a":2}');
  assert.deepEqual(JSON.parse(fs.readFileSync(f, 'utf8')), { a: 2 });
  assert.equal(fs.readdirSync(path.dirname(f)).filter(n => n.includes('.tmp-')).length, 0);
});

test('saveCurrentAsProfile snapshots the live account', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  const res = app.saveCurrentAsProfile(paths, 'work');
  assert.deepEqual(res, { name: 'work', updated: false });
  const store = app.loadProfiles(paths);
  assert.equal(store.profiles.work.account.emailAddress, 'a@test.com');
  assert.equal(store.profiles.work.credentials.refreshToken, 'refresh-A');
  assert.equal(store.activeProfile, 'work');
  assert.ok(store.profiles.work.savedAt);
});

test('saveCurrentAsProfile throws 409 when not logged in', () => {
  const paths = makeTmpEnv();
  assert.throws(() => app.saveCurrentAsProfile(paths, 'work'), /login/i);
});

test('saving the same account again updates the existing profile, no duplicate', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  app.saveCurrentAsProfile(paths, 'work');
  writeFakeLogin(paths, 'A', { tag: '-v2' });
  const res = app.saveCurrentAsProfile(paths, 'differentName');
  assert.deepEqual(res, { name: 'work', updated: true });
  const store = app.loadProfiles(paths);
  assert.equal(Object.keys(store.profiles).length, 1);
  assert.equal(store.profiles.work.credentials.accessToken, 'access-A-v2');
});

test('name collision with a different account throws 409', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  app.saveCurrentAsProfile(paths, 'work');
  writeFakeLogin(paths, 'B');
  assert.throws(() => app.saveCurrentAsProfile(paths, 'work'), /already exists/i);
});

test('sanitizeName rejects empty and >40 chars', () => {
  assert.throws(() => app.sanitizeName(''), /1-40/);
  assert.throws(() => app.sanitizeName('x'.repeat(41)), /1-40/);
  assert.equal(app.sanitizeName('  work  '), 'work');
});

test('renameProfile moves entry and updates activeProfile', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  app.saveCurrentAsProfile(paths, 'work');
  app.renameProfile(paths, 'work', 'office');
  const store = app.loadProfiles(paths);
  assert.ok(store.profiles.office);
  assert.equal(store.profiles.work, undefined);
  assert.equal(store.activeProfile, 'office');
  assert.throws(() => app.renameProfile(paths, 'nope', 'x'), /not found/i);
});

test('deleteProfile removes entry and clears activeProfile if it pointed there', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  app.saveCurrentAsProfile(paths, 'work');
  app.deleteProfile(paths, 'work');
  const store = app.loadProfiles(paths);
  assert.equal(Object.keys(store.profiles).length, 0);
  assert.equal(store.activeProfile, null);
});

test('switchToProfile writes target tokens and patches only oauthAccount', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  app.saveCurrentAsProfile(paths, 'acct-a');
  writeFakeLogin(paths, 'B');
  app.saveCurrentAsProfile(paths, 'acct-b');
  const res = app.switchToProfile(paths, 'acct-a');
  assert.deepEqual(res, { switched: 'acct-a' });
  const creds = JSON.parse(fs.readFileSync(paths.credentials, 'utf8'));
  assert.equal(creds.claudeAiOauth.accessToken, 'access-A');
  const cj = JSON.parse(fs.readFileSync(paths.claudeJson, 'utf8'));
  assert.equal(cj.oauthAccount.accountUuid, 'uuid-A');
  assert.equal(cj.unrelatedKey, 'preserve-me');
  assert.equal(app.loadProfiles(paths).activeProfile, 'acct-a');
});

test('switch syncs refreshed live tokens back into the matching profile first', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  app.saveCurrentAsProfile(paths, 'acct-a');
  writeFakeLogin(paths, 'B');
  app.saveCurrentAsProfile(paths, 'acct-b');
  writeFakeLogin(paths, 'B', { tag: '-refreshed' });
  app.switchToProfile(paths, 'acct-a');
  const store = app.loadProfiles(paths);
  assert.equal(store.profiles['acct-b'].credentials.refreshToken, 'refresh-B-refreshed');
});

test('switch to a profile with expired refresh token throws 409', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A', { refreshTokenExpiresAt: Date.now() - 1000 });
  app.saveCurrentAsProfile(paths, 'stale');
  writeFakeLogin(paths, 'B');
  assert.throws(() => app.switchToProfile(paths, 'stale'), /expired/i);
});

test('switch aborts without writing when .claude.json is corrupt', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  app.saveCurrentAsProfile(paths, 'acct-a');
  fs.writeFileSync(paths.claudeJson, '{ this is not json');
  assert.throws(() => app.switchToProfile(paths, 'acct-a'));
  const rawCreds = fs.readFileSync(paths.credentials, 'utf8');
  assert.ok(rawCreds.includes('access-A'));
});

test('each switch creates a backup, pruned to 10', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  app.saveCurrentAsProfile(paths, 'acct-a');
  for (let i = 0; i < 12; i++) app.makeBackup(paths);
  assert.equal(app.listBackups(paths).length, 10);
});

test('restoreBackup puts old files back, even when backups are at capacity', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  const backupId = app.makeBackup(paths);
  writeFakeLogin(paths, 'B');
  for (let i = 0; i < 9; i++) app.makeBackup(paths);
  const res = app.restoreBackup(paths, backupId);
  assert.equal(res.restored, backupId);
  const creds = JSON.parse(fs.readFileSync(paths.credentials, 'utf8'));
  assert.equal(creds.claudeAiOauth.accessToken, 'access-A');
});

test('restoreBackup rejects path-traversal ids', () => {
  const paths = makeTmpEnv();
  assert.throws(() => app.restoreBackup(paths, '..\\..\\evil'), /bad backup id/i);
});

test('getState reports live account, matched profile, and never leaks tokens', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  app.saveCurrentAsProfile(paths, 'acct-a');
  const state = app.getState(paths);
  assert.equal(state.live.loggedIn, true);
  assert.equal(state.live.email, 'a@test.com');
  assert.equal(state.live.matchedProfile, 'acct-a');
  assert.equal(state.profiles[0].isLive, true);
  assert.ok(!JSON.stringify(state).includes('access-A'));
  assert.ok(!JSON.stringify(state).includes('refresh-A'));
});

test('getState flags drift when live account matches no profile', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  app.saveCurrentAsProfile(paths, 'acct-a');
  writeFakeLogin(paths, 'B');
  const state = app.getState(paths);
  assert.equal(state.live.matchedProfile, null);
  assert.equal(state.live.email, 'b@test.com');
});

async function withServer(paths, fn) {
  const server = app.createServer(paths);
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  try { await fn(base); } finally { server.close(); }
}

test('API: full save/switch/delete round trip', async () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  await withServer(paths, async base => {
    let res = await fetch(base + '/api/profiles', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: 'acct-a' }),
    });
    assert.equal(res.status, 200);

    writeFakeLogin(paths, 'B');
    await fetch(base + '/api/profiles', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: 'acct-b' }),
    });

    res = await fetch(base + '/api/switch', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: 'acct-a' }),
    });
    assert.deepEqual(await res.json(), { switched: 'acct-a' });

    res = await fetch(base + '/api/state');
    const state = await res.json();
    assert.equal(state.live.email, 'a@test.com');
    assert.equal(state.profiles.length, 2);

    res = await fetch(base + '/api/profiles/acct-b', { method: 'DELETE', headers: { 'Content-Type': 'application/json' } });
    assert.equal(res.status, 200);
    res = await fetch(base + '/api/state');
    assert.equal((await res.json()).profiles.length, 1);
  });
});

test('API: errors carry status and message, unknown route is 404', async () => {
  const paths = makeTmpEnv();
  await withServer(paths, async base => {
    let res = await fetch(base + '/api/switch', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: 'ghost' }),
    });
    assert.equal(res.status, 404);
    assert.match((await res.json()).error, /not found/i);

    res = await fetch(base + '/api/nope');
    assert.equal(res.status, 404);
  });
});

function fakeUsageResponse(pct) {
  return {
    five_hour: { utilization: pct, resets_at: '2026-07-14T18:59:59.000000+00:00' },
    seven_day: { utilization: pct / 2, resets_at: '2026-07-18T14:59:59.000000+00:00' },
    seven_day_opus: null,
  };
}
function jsonRes(status, body) {
  return { ok: status >= 200 && status < 300, status, json: async () => body };
}

test('getUsage uses live token for the live profile and stored token for others', async () => {
  app._clearUsageCache();
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  app.saveCurrentAsProfile(paths, 'acct-a');
  writeFakeLogin(paths, 'B');
  app.saveCurrentAsProfile(paths, 'acct-b');
  writeFakeLogin(paths, 'B', { tag: '-live' });
  const tokens = [];
  const fetchImpl = async (url, opts) => {
    tokens.push(opts.headers.Authorization.replace('Bearer ', ''));
    return jsonRes(200, fakeUsageResponse(40));
  };
  const res = await app.getUsage(paths, fetchImpl);
  assert.ok(tokens.includes('access-A'));
  assert.ok(tokens.includes('access-B-live'));
  assert.equal(res.profiles['acct-a'].fiveHour.utilization, 40);
  assert.equal(res.profiles['acct-b'].sevenDay.utilization, 20);
});

test('getUsage caches results per account', async () => {
  app._clearUsageCache();
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  app.saveCurrentAsProfile(paths, 'acct-a');
  let calls = 0;
  const fetchImpl = async () => { calls++; return jsonRes(200, fakeUsageResponse(10)); };
  await app.getUsage(paths, fetchImpl);
  await app.getUsage(paths, fetchImpl);
  assert.equal(calls, 1);
});

test('getUsage refreshes an expired stored token, saves it, and retries', async () => {
  app._clearUsageCache();
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  app.saveCurrentAsProfile(paths, 'acct-a');
  writeFakeLogin(paths, 'B');
  app.saveCurrentAsProfile(paths, 'acct-b');
  const seen = [];
  const fetchImpl = async (url, opts) => {
    if (url.includes('/oauth/token')) {
      seen.push('refresh:' + JSON.parse(opts.body).refresh_token);
      return jsonRes(200, { access_token: 'access-A-new', refresh_token: 'refresh-A-new', expires_in: 3600 });
    }
    const token = opts.headers.Authorization.replace('Bearer ', '');
    seen.push('usage:' + token);
    if (token === 'access-A') return jsonRes(401, {});
    return jsonRes(200, fakeUsageResponse(55));
  };
  const res = await app.getUsage(paths, fetchImpl);
  assert.equal(res.profiles['acct-a'].fiveHour.utilization, 55);
  assert.ok(seen.includes('refresh:refresh-A'));
  assert.ok(seen.includes('usage:access-A-new'));
  const store = app.loadProfiles(paths);
  assert.equal(store.profiles['acct-a'].credentials.accessToken, 'access-A-new');
  assert.equal(store.profiles['acct-a'].credentials.refreshToken, 'refresh-A-new');
});

test('getUsage parses the modern limits array including model-scoped limits like Fable', async () => {
  app._clearUsageCache();
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  app.saveCurrentAsProfile(paths, 'acct-a');
  const modern = {
    five_hour: null, seven_day: null,
    limits: [
      { kind: 'session', group: 'session', percent: 28, resets_at: '2026-07-14T19:20:00Z' },
      { kind: 'weekly_all', group: 'weekly', percent: 55, resets_at: '2026-07-18T16:00:00Z' },
      { kind: 'weekly_scoped', group: 'weekly', percent: 68, resets_at: '2026-07-18T16:00:00Z',
        scope: { model: { id: null, display_name: 'Fable' }, surface: null }, is_active: true },
    ],
  };
  const res = await app.getUsage(paths, async () => jsonRes(200, modern));
  const u = res.profiles['acct-a'];
  assert.equal(u.fiveHour.utilization, 28);
  assert.equal(u.sevenDay.utilization, 55);
  assert.deepEqual(u.models, [{ label: 'Fable', utilization: 68, resetsAt: '2026-07-18T16:00:00Z' }]);
});

test('getUsage reports a friendly error and never throws when the API fails', async () => {
  app._clearUsageCache();
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  app.saveCurrentAsProfile(paths, 'acct-a');
  const res = await app.getUsage(paths, async () => jsonRes(429, {}));
  assert.ok(res.profiles['acct-a'].error);
  assert.ok(!JSON.stringify(res).includes('access-A'));
});

test('autostart: enable creates the Startup file, disable removes it, state reports it', () => {
  const paths = makeTmpEnv();
  assert.equal(app.getState(paths).autostart, false);
  app.setAutostart(paths, true);
  assert.ok(fs.existsSync(paths.startup));
  assert.ok(fs.readFileSync(paths.startup, 'utf8').includes('server.js'));
  assert.equal(app.getState(paths).autostart, true);
  app.setAutostart(paths, false);
  assert.equal(fs.existsSync(paths.startup), false);
});

test('getPaths puts the startup file under APPDATA', () => {
  const p = app.getPaths({ SWITCHER_HOME: '/tmp/h', SWITCHER_DATA_DIR: '/tmp/d', APPDATA: '/tmp/appdata' });
  assert.ok(p.startup.includes(path.join('appdata', 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup')));
});

test('switching logs an activity event, newest first', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  app.saveCurrentAsProfile(paths, 'acct-a');
  writeFakeLogin(paths, 'B');
  app.saveCurrentAsProfile(paths, 'acct-b');
  app.switchToProfile(paths, 'acct-a');
  const events = app.listEvents(paths);
  assert.equal(events[0].type, 'switched');
  assert.equal(events[0].name, 'acct-a');
  assert.ok(events.some(e => e.type === 'saved'));
});

test('export writes a file to disk and import moves accounts to a fresh machine', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  app.saveCurrentAsProfile(paths, 'work');
  writeFakeLogin(paths, 'B');
  app.saveCurrentAsProfile(paths, 'personal');
  const res1 = app.exportProfiles(paths);
  assert.equal(res1.accounts, 2);
  assert.ok(fs.existsSync(res1.file));
  const exported = JSON.parse(fs.readFileSync(res1.file, 'utf8'));
  assert.equal(exported.app, 'claude-account-switcher');

  const fresh = makeTmpEnv();
  const res = app.importProfiles(fresh, exported);
  assert.deepEqual(res, { added: 2, updated: 0, skipped: 0 });
  const store = app.loadProfiles(fresh);
  assert.equal(store.profiles.work.account.accountUuid, 'uuid-A');
  assert.deepEqual(app.importProfiles(fresh, exported), { added: 0, updated: 0, skipped: 2 });
});

test('import handles name collisions within 40 chars and skips bad entries', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  const longName = 'x'.repeat(40);
  app.saveCurrentAsProfile(paths, longName);
  const data = {
    app: 'claude-account-switcher',
    profiles: {
      [longName]: {
        credentials: { accessToken: 'access-B', refreshToken: 'refresh-B', refreshTokenExpiresAt: Date.now() + 86400e3 },
        account: { accountUuid: 'uuid-B', emailAddress: 'b@test.com' },
        savedAt: new Date().toISOString(),
      },
      'bad"name': {
        credentials: { accessToken: 'access-C' },
        account: { accountUuid: 'uuid-C' },
      },
    },
  };
  const res = app.importProfiles(paths, data);
  assert.equal(res.added, 1);
  assert.equal(res.skipped, 1);
  const store = app.loadProfiles(paths);
  const importedName = Object.keys(store.profiles).find(n => store.profiles[n].account.accountUuid === 'uuid-B');
  assert.equal(importedName.length <= 40, true);
  assert.notEqual(importedName, longName);
});

test('import rejects a null profiles key', () => {
  const paths = makeTmpEnv();
  assert.throws(() => app.importProfiles(paths, { app: 'claude-account-switcher', profiles: null }), /not a Claude Account Switcher export/i);
});

test('concurrent token refreshes both persist (no lost update)', async () => {
  app._clearUsageCache();
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  app.saveCurrentAsProfile(paths, 'pa');
  writeFakeLogin(paths, 'B');
  app.saveCurrentAsProfile(paths, 'pb');
  writeFakeLogin(paths, 'C');
  const fetchImpl = async (url, opts) => {
    if (url.includes('/oauth/token')) {
      const letter = JSON.parse(opts.body).refresh_token.replace('refresh-', '');
      await new Promise(r => setTimeout(r, 20));
      return jsonRes(200, { access_token: `access-${letter}-new`, refresh_token: `refresh-${letter}-new`, expires_in: 3600 });
    }
    const token = opts.headers.Authorization.replace('Bearer ', '');
    if (token.endsWith('-new') || token === 'access-C') return jsonRes(200, fakeUsageResponse(10));
    return jsonRes(401, {});
  };
  await app.getUsage(paths, fetchImpl);
  const store = app.loadProfiles(paths);
  assert.equal(store.profiles.pa.credentials.refreshToken, 'refresh-A-new');
  assert.equal(store.profiles.pb.credentials.refreshToken, 'refresh-B-new');
});

test('logEvent caps the history file', () => {
  const paths = makeTmpEnv();
  for (let i = 0; i < 401; i++) app.logEvent(paths, 'switched', { name: 'n' + i });
  const lines = fs.readFileSync(paths.events, 'utf8').trimEnd().split('\n');
  assert.ok(lines.length <= 400);
  assert.equal(app.listEvents(paths).length, 30);
  assert.equal(app.listEvents(paths)[0].name, 'n400');
});

test('import rejects files that are not switcher exports', () => {
  const paths = makeTmpEnv();
  assert.throws(() => app.importProfiles(paths, { some: 'garbage' }), /not a Claude Account Switcher export/i);
  assert.throws(() => app.importProfiles(paths, null), /not a Claude Account Switcher export/i);
});

test('API: health, events, and export endpoints respond correctly', async () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  await withServer(paths, async base => {
    const health = await (await fetch(base + '/api/health')).json();
    assert.equal(health.app, 'claude-account-switcher');
    assert.ok(health.version);

    await fetch(base + '/api/profiles', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: 'acct-a' }),
    });
    const events = await (await fetch(base + '/api/events')).json();
    assert.equal(events[0].type, 'saved');

    let res = await fetch(base + '/api/export');
    assert.equal(res.status, 404);
    res = await fetch(base + '/api/export', { method: 'POST', headers: { 'Content-Type': 'application/json' } });
    assert.equal(res.status, 200);
    const exported = await res.json();
    assert.equal(exported.accounts, 1);
    assert.ok(!JSON.stringify(exported).includes('access-A'));
    assert.ok(fs.existsSync(exported.file));
  });
});

test('damaged profiles.json is preserved, never silently wiped', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  app.saveCurrentAsProfile(paths, 'work');
  fs.writeFileSync(paths.profiles, '{ not valid json');
  assert.throws(() => app.saveCurrentAsProfile(paths, 'other'), /damaged/i);
  assert.equal(fs.readFileSync(paths.profiles, 'utf8'), '{ not valid json');
  const aside = fs.readdirSync(path.dirname(paths.profiles)).find(f => f.includes('.corrupt-'));
  assert.ok(aside, 'a .corrupt- copy should exist');
});

test('sanitizeName rejects quotes and angle brackets', () => {
  for (const bad of ["O'Brien", 'a"b', 'x<script>', 'a\\b', 'tick`name']) {
    assert.throws(() => app.sanitizeName(bad), /cannot contain/i, bad);
  }
});

test('getState survives a damaged profile entry', () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  app.saveCurrentAsProfile(paths, 'good');
  const store = app.loadProfiles(paths);
  store.profiles.broken = { savedAt: 'x' };
  app.saveProfiles(paths, store);
  const state = app.getState(paths);
  assert.equal(state.profiles.length, 2);
  assert.equal(state.profiles.find(p => p.name === 'broken').damaged, true);
  assert.throws(() => app.switchToProfile(paths, 'broken'), /damaged/i);
});

test('security: foreign Host, foreign Origin, and non-JSON POST are rejected', async () => {
  const http = require('http');
  const rawRequest = (port, options) => new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port, ...options }, res => resolve(res.statusCode));
    req.on('error', reject);
    req.end(options.body);
  });
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  await withServer(paths, async base => {
    const port = Number(new URL(base).port);
    assert.equal(await rawRequest(port, { path: '/api/state', headers: { Host: 'evil.example.com' } }), 403);
    assert.equal(await rawRequest(port, {
      method: 'POST', path: '/api/open-login',
      headers: { Host: 'localhost', Origin: 'https://evil.example.com', 'Content-Type': 'application/json' },
    }), 403);
    assert.equal(await rawRequest(port, {
      method: 'POST', path: '/api/open-login',
      headers: { Host: 'localhost', 'Content-Type': 'text/plain' }, body: '{}',
    }), 403);
    assert.equal(await rawRequest(port, {
      method: 'DELETE', path: '/api/profiles/x', headers: { Host: 'localhost' },
    }), 403);
    assert.equal(await rawRequest(port, {
      method: 'POST', path: '/api/open-login',
      headers: { Host: 'localhost:' + port, Origin: 'http://localhost:3000', 'Content-Type': 'application/json' },
    }), 403);
    assert.equal(await rawRequest(port, {
      path: '/api/state', headers: { Host: '127.0.0.1:' + port, Origin: 'http://127.0.0.1:' + port },
    }), 200);
  });
});

test('API: POST /api/open-login calls the injected terminal launcher', async () => {
  const paths = makeTmpEnv();
  const calls = [];
  const server = app.createServer(paths, { openLogin: () => calls.push(1) });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  try {
    const res = await fetch(base + '/api/open-login', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
    });
    assert.equal(res.status, 200);
    assert.deepEqual(await res.json(), { ok: true });
    assert.equal(calls.length, 1);
  } finally { server.close(); }
});

test('API: rename via PATCH', async () => {
  const paths = makeTmpEnv();
  writeFakeLogin(paths, 'A');
  await withServer(paths, async base => {
    await fetch(base + '/api/profiles', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: 'old' }),
    });
    const res = await fetch(base + '/api/profiles/old', {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ newName: 'new' }),
    });
    assert.equal(res.status, 200);
    const state = await (await fetch(base + '/api/state')).json();
    assert.equal(state.profiles[0].name, 'new');
  });
});
